package com.cozmo.robot_ia_app

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.hardware.input.InputManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaPlayer
import android.os.PowerManager
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicLong
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Puente Bluetooth clásico (SPP / RFCOMM) para los módulos HC-05.
 * Maneja hasta dos conexiones simultáneas identificadas por "slot" ("rx" y "tx").
 */
class MainActivity : FlutterActivity() {

    companion object {
        private const val METHOD_CHANNEL = "cozmo/bt"
        private const val EVENT_CHANNEL = "cozmo/bt_events"
        private const val PAD_EVENT_CHANNEL = "cozmo/gamepad"
        private const val MUSIC_CHANNEL = "cozmo/music"
        private const val SYS_CHANNEL = "cozmo/sys"
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val io: ExecutorService = Executors.newCachedThreadPool()
    private val sockets = ConcurrentHashMap<String, BluetoothSocket>()
    private var sink: EventChannel.EventSink? = null
    private var discoveryReceiver: BroadcastReceiver? = null

    // ---- Gamepad / música (agregado) ----
    private var padSink: EventChannel.EventSink? = null
    private var inputListener: InputManager.InputDeviceListener? = null
    private val lastAxes = FloatArray(8)
    private var music: MusicEngine? = null

    private fun adapter(): BluetoothAdapter? {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        return manager?.adapter
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger

        EventChannel(messenger, EVENT_CHANNEL).setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                sink = events
            }

            override fun onCancel(arguments: Any?) {
                sink = null
            }
        })

        MethodChannel(messenger, METHOD_CHANNEL).setMethodCallHandler { call, result ->
            handle(call, result)
        }

        // ---- Gamepad (Bluetooth HID del sistema) ----
        EventChannel(messenger, PAD_EVENT_CHANNEL).setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                padSink = events
                emitPadDevices()
            }

            override fun onCancel(arguments: Any?) {
                padSink = null
            }
        })
        registerPadListener()

        // ---- Música + utilidades del sistema ----
        val engine = MusicEngine(this, sockets)
        music = engine
        MethodChannel(messenger, MUSIC_CHANNEL).setMethodCallHandler { call, result ->
            handleMusic(engine, call, result)
        }
        MethodChannel(messenger, SYS_CHANNEL).setMethodCallHandler { call, result ->
            handleSys(call, result)
        }
    }

    private fun handle(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "isEnabled" -> {
                val enabled = try {
                    adapter()?.isEnabled == true
                } catch (e: SecurityException) {
                    false
                }
                result.success(enabled)
            }

            "requestEnable" -> {
                try {
                    startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
                    result.success(true)
                } catch (e: Exception) {
                    result.success(false)
                }
            }

            "bonded" -> bonded(result)
            "startDiscovery" -> startDiscovery(result)

            "stopDiscovery" -> {
                stopDiscovery()
                result.success(true)
            }

            "connect" -> {
                val slot = call.argument<String>("slot")
                val address = call.argument<String>("address")
                if (slot == null || address == null) {
                    result.error("ARGS", "Faltan datos para conectar", null)
                    return
                }
                io.execute {
                    try {
                        connectBlocking(slot, address)
                        mainHandler.post { result.success(true) }
                    } catch (e: SecurityException) {
                        mainHandler.post {
                            result.error(
                                "PERMISSION",
                                "Falta el permiso de Bluetooth (Dispositivos cercanos). Actívalo en los ajustes del celular.",
                                null
                            )
                        }
                    } catch (e: Exception) {
                        mainHandler.post { result.error("CONNECT", e.message ?: e.toString(), null) }
                    }
                }
            }

            "disconnect" -> {
                closeSlot(call.argument<String>("slot") ?: "")
                result.success(true)
            }

            "write" -> write(call, result)

            else -> result.notImplemented()
        }
    }

    private fun bonded(result: MethodChannel.Result) {
        val ad = adapter()
        if (ad == null) {
            result.error("NO_BT", "Este celular no tiene Bluetooth", null)
            return
        }
        try {
            val list = ad.bondedDevices.map { d ->
                mapOf("name" to (d.name ?: ""), "address" to d.address)
            }
            result.success(list)
        } catch (e: SecurityException) {
            result.error("PERMISSION", "Falta el permiso de Bluetooth (Dispositivos cercanos)", null)
        }
    }

    private fun startDiscovery(result: MethodChannel.Result) {
        val ad = adapter()
        if (ad == null) {
            result.error("NO_BT", "Este celular no tiene Bluetooth", null)
            return
        }
        try {
            stopDiscovery()

            val receiver = object : BroadcastReceiver() {
                @Suppress("DEPRECATION")
                override fun onReceive(context: Context?, intent: Intent?) {
                    val i = intent ?: return
                    val action = i.action
                    if (action == BluetoothDevice.ACTION_FOUND) {
                        val dev: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
                            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        } else {
                            i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                        }
                        if (dev != null) {
                            val name = try {
                                dev.name ?: ""
                            } catch (e: SecurityException) {
                                ""
                            }
                            sink?.success(
                                mapOf("type" to "found", "name" to name, "address" to dev.address)
                            )
                        }
                    } else if (action == BluetoothAdapter.ACTION_DISCOVERY_FINISHED) {
                        sink?.success(mapOf("type" to "scanDone"))
                        stopDiscovery()
                    }
                }
            }

            val filter = IntentFilter()
            filter.addAction(BluetoothDevice.ACTION_FOUND)
            filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                registerReceiver(receiver, filter)
            }
            discoveryReceiver = receiver

            val started = ad.startDiscovery()
            if (!started) stopDiscovery()
            result.success(started)
        } catch (e: SecurityException) {
            stopDiscovery()
            result.error("PERMISSION", "Falta el permiso de Bluetooth (Dispositivos cercanos)", null)
        }
    }

    private fun stopDiscovery() {
        try {
            adapter()?.cancelDiscovery()
        } catch (e: SecurityException) {
            // sin permiso de escaneo: no hay nada que cancelar
        }
        val r = discoveryReceiver
        discoveryReceiver = null
        if (r != null) {
            try {
                unregisterReceiver(r)
            } catch (e: Exception) {
                // ya estaba desregistrado
            }
        }
    }

    /** Empareja (si hace falta) y abre el socket RFCOMM. Se ejecuta en un hilo de fondo. */
    private fun connectBlocking(slot: String, address: String) {
        val ad = adapter() ?: throw IOException("Este celular no tiene Bluetooth")
        if (!ad.isEnabled) throw IOException("El Bluetooth está apagado")

        try {
            ad.cancelDiscovery()
        } catch (e: SecurityException) {
            // ignorar: solo mejora la velocidad de conexión
        }

        val dev = ad.getRemoteDevice(address)
        closeSlot(slot)
        ensureBonded(dev)

        var sock: BluetoothSocket = dev.createRfcommSocketToServiceRecord(SPP_UUID)
        try {
            sock.connect()
        } catch (first: IOException) {
            try {
                sock.close()
            } catch (ignored: IOException) {
            }
            try {
                // Método alterno muy usado con módulos HC-05 que rechazan el UUID estándar
                val method = dev.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                sock = method.invoke(dev, 1) as BluetoothSocket
                sock.connect()
            } catch (second: Exception) {
                try {
                    sock.close()
                } catch (ignored: Exception) {
                }
                throw IOException(
                    "No se pudo conectar al HC-05. Verifica que esté encendido, cerca del celular " +
                        "y que la clave sea 1234 o 0000. También revisa que no esté conectado a otro dispositivo."
                )
            }
        }

        sockets[slot] = sock
        startReader(slot, sock)
    }

    private fun ensureBonded(dev: BluetoothDevice) {
        if (dev.bondState == BluetoothDevice.BOND_BONDED) return
        dev.createBond()
        val deadline = System.currentTimeMillis() + 60_000
        var sawBonding = false
        while (System.currentTimeMillis() < deadline) {
            val state = dev.bondState
            if (state == BluetoothDevice.BOND_BONDED) return
            if (state == BluetoothDevice.BOND_BONDING) sawBonding = true
            if (state == BluetoothDevice.BOND_NONE && sawBonding) {
                throw IOException("El emparejamiento fue rechazado (clave incorrecta). Usa 1234 o 0000.")
            }
            Thread.sleep(400)
        }
        throw IOException("Se agotó el tiempo esperando el emparejamiento con el HC-05")
    }

    private fun startReader(slot: String, sock: BluetoothSocket) {
        Thread {
            val buffer = ByteArray(2048)
            try {
                val input = sock.inputStream
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    if (n == 0) continue
                    val chunk = buffer.copyOf(n)
                    mainHandler.post {
                        sink?.success(mapOf("slot" to slot, "type" to "data", "data" to chunk))
                    }
                }
            } catch (e: IOException) {
                // conexión cerrada o perdida
            }
            if (sockets.remove(slot, sock)) {
                try {
                    sock.close()
                } catch (ignored: IOException) {
                }
                mainHandler.post {
                    sink?.success(mapOf("slot" to slot, "type" to "closed"))
                }
            }
        }.start()
    }

    private fun write(call: MethodCall, result: MethodChannel.Result) {
        val slot = call.argument<String>("slot") ?: ""
        val data = call.argument<ByteArray>("data")
        val sock = sockets[slot]
        if (sock == null || data == null) {
            result.error("NOT_CONNECTED", "El HC-05 no está conectado", null)
            return
        }
        io.execute {
            try {
                val out = sock.outputStream
                out.write(data)
                out.flush()
                mainHandler.post { result.success(true) }
            } catch (e: IOException) {
                if (sockets.remove(slot, sock)) {
                    try {
                        sock.close()
                    } catch (ignored: IOException) {
                    }
                    mainHandler.post {
                        sink?.success(mapOf("slot" to slot, "type" to "closed"))
                    }
                }
                mainHandler.post { result.error("WRITE", e.message ?: "Error al enviar", null) }
            }
        }
    }

    private fun closeSlot(slot: String) {
        val s = sockets.remove(slot) ?: return
        try {
            s.close()
        } catch (e: IOException) {
            // ya cerrado
        }
    }

    // ======================= GAMEPAD =======================

    private fun gamepadNames(): List<String> {
        val names = ArrayList<String>()
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            val s = d.sources
            val isPad = (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
            if (isPad && !d.isVirtual) names.add(d.name ?: "Gamepad")
        }
        return names
    }

    private fun emitPadDevices() {
        padSink?.success(mapOf("type" to "devices", "names" to gamepadNames()))
    }

    private fun sendZeroAxes() {
        for (i in lastAxes.indices) lastAxes[i] = 0f
        padSink?.success(mapOf("type" to "axes", "v" to List(8) { 0.0 }))
    }

    private fun registerPadListener() {
        val im = getSystemService(Context.INPUT_SERVICE) as? InputManager ?: return
        val l = object : InputManager.InputDeviceListener {
            override fun onInputDeviceAdded(deviceId: Int) {
                emitPadDevices()
            }

            override fun onInputDeviceRemoved(deviceId: Int) {
                emitPadDevices()
                sendZeroAxes()
            }

            override fun onInputDeviceChanged(deviceId: Int) {
                emitPadDevices()
            }
        }
        inputListener = l
        im.registerInputDeviceListener(l, mainHandler)
    }

    private fun unregisterPadListener() {
        val l = inputListener ?: return
        inputListener = null
        val im = getSystemService(Context.INPUT_SERVICE) as? InputManager ?: return
        try {
            im.unregisterInputDeviceListener(l)
        } catch (e: Exception) {
            // ignorar
        }
    }

    /** Sticks analógicos, gatillos y cruceta (hat) del gamepad. */
    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        if ((ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
            ev.action == MotionEvent.ACTION_MOVE
        ) {
            emitAxes(ev)
            return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    private fun emitAxes(ev: MotionEvent) {
        val dev = ev.device
        val hasZ = dev?.getMotionRange(MotionEvent.AXIS_Z, ev.source) != null
        val hasRZ = dev?.getMotionRange(MotionEvent.AXIS_RZ, ev.source) != null
        val rx = if (hasZ) ev.getAxisValue(MotionEvent.AXIS_Z) else ev.getAxisValue(MotionEvent.AXIS_RX)
        val ry = if (hasRZ) ev.getAxisValue(MotionEvent.AXIS_RZ) else ev.getAxisValue(MotionEvent.AXIS_RY)
        val lt = maxOf(ev.getAxisValue(MotionEvent.AXIS_LTRIGGER), ev.getAxisValue(MotionEvent.AXIS_BRAKE))
        val rt = maxOf(ev.getAxisValue(MotionEvent.AXIS_RTRIGGER), ev.getAxisValue(MotionEvent.AXIS_GAS))
        val cur = floatArrayOf(
            ev.getAxisValue(MotionEvent.AXIS_X),
            ev.getAxisValue(MotionEvent.AXIS_Y),
            rx,
            ry,
            lt,
            rt,
            ev.getAxisValue(MotionEvent.AXIS_HAT_X),
            ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
        )
        var changed = false
        for (i in cur.indices) {
            if (Math.abs(cur[i] - lastAxes[i]) > 0.004f) changed = true
        }
        if (!changed) return
        for (i in cur.indices) lastAxes[i] = cur[i]
        padSink?.success(mapOf("type" to "axes", "v" to cur.map { it.toDouble() }))
    }

    /** Botones del gamepad (A, B, X, Y, L1, R1, Start, Select, cruceta...). */
    override fun dispatchKeyEvent(ev: KeyEvent): Boolean {
        val src = ev.source
        val fromPad = (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        val code = ev.keyCode
        val dpad = code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN ||
            code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT ||
            code == KeyEvent.KEYCODE_DPAD_CENTER
        if (fromPad && (KeyEvent.isGamepadButton(code) || dpad)) {
            if (ev.repeatCount == 0) {
                padSink?.success(
                    mapOf("type" to "button", "code" to code, "down" to (ev.action == KeyEvent.ACTION_DOWN))
                )
            }
            return true
        }
        return super.dispatchKeyEvent(ev)
    }

    // ================== SISTEMA (ruta de audio, ajustes BT, pantalla) ==================

    private fun handleSys(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "gamepads" -> result.success(gamepadNames())

            "openBtSettings" -> {
                try {
                    startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                    result.success(true)
                } catch (e: Exception) {
                    result.success(false)
                }
            }

            "audioRoute" -> {
                var name: String? = null
                try {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    for (d in am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                        if (d.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP) {
                            val n = d.productName?.toString()
                            name = if (n.isNullOrEmpty()) "Bluetooth" else n
                            break
                        }
                    }
                } catch (e: Exception) {
                    name = null
                }
                result.success(mapOf("a2dp" to (name != null), "name" to (name ?: "")))
            }

            "keepScreenOn" -> {
                val on = call.argument<Boolean>("on") ?: false
                runOnUiThread {
                    if (on) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    } else {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                }
                result.success(true)
            }

            else -> result.notImplemented()
        }
    }

    // ============================= MÚSICA =============================

    private fun handleMusic(engine: MusicEngine, call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "load" -> {
                    val path = call.argument<String>("path") ?: throw IOException("Falta la canción")
                    val output = call.argument<String>("output") ?: "phone"
                    val rate = call.argument<Int>("rate") ?: 8000
                    val volume = call.argument<Double>("volume") ?: 0.8
                    val start = call.argument<Int>("start") ?: 0
                    val dur = engine.load(path, output, rate, volume.toFloat(), start)
                    result.success(mapOf("duration" to dur))
                }

                "play" -> {
                    engine.play()
                    result.success(true)
                }

                "pause" -> {
                    engine.pause()
                    result.success(true)
                }

                "stop" -> {
                    engine.stop()
                    result.success(true)
                }

                "seek" -> {
                    engine.seek((call.argument<Int>("ms") ?: 0).toLong())
                    result.success(true)
                }

                "volume" -> {
                    engine.setVolume((call.argument<Double>("v") ?: 0.8).toFloat())
                    result.success(true)
                }

                "status" -> result.success(engine.status())

                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("MUSIC", e.message ?: e.toString(), null)
        }
    }

    override fun onDestroy() {
        music?.stop()
        unregisterPadListener()
        stopDiscovery()
        for (key in sockets.keys.toList()) closeSlot(key)
        io.shutdownNow()
        super.onDestroy()
    }
}


/**
 * Motor de música.
 *  - output "phone": MediaPlayer normal. Android lo manda solo al parlante Bluetooth (A2DP)
 *    si hay uno conectado (placa de parlante viejo), o al altavoz del celular.
 *  - output "hc05": decodifica el archivo (MediaCodec), lo pasa a PCM 8 bits sin signo mono
 *    a [rate] Hz (el mismo formato que usa la voz del robot) y lo envía por el socket del
 *    HC-05 #2 (slot "tx") al ritmo de reproducción.
 */
class MusicEngine(
    private val ctx: Context,
    private val sockets: ConcurrentHashMap<String, BluetoothSocket>
) {
    private var player: MediaPlayer? = null
    private var worker: Thread? = null
    private var output = "phone"
    private var path = ""
    private var rate = 8000
    private var wake: PowerManager.WakeLock? = null

    @Volatile private var volume = 0.8f
    @Volatile private var state = "idle"
    @Volatile private var posMs = 0L
    @Volatile private var durMs = 0L
    @Volatile private var error = ""
    @Volatile private var paused = false
    @Volatile private var gen = 0
    private val seekReq = AtomicLong(-1L)

    @Synchronized
    fun load(p: String, out: String, r: Int, vol: Float, startMs: Int): Long {
        release()
        path = p
        output = out
        rate = if (r < 4000) 8000 else r
        volume = vol.coerceIn(0f, 1f)
        error = ""
        posMs = startMs.toLong()
        durMs = 0L

        if (out == "hc05") {
            if (sockets["tx"] == null) {
                throw IOException("El HC-05 #2 no está conectado. Conéctalo en la pestaña Conexión.")
            }
            val ex = MediaExtractor()
            try {
                ex.setDataSource(p)
                var found = false
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("audio/")) {
                        found = true
                        if (f.containsKey(MediaFormat.KEY_DURATION)) {
                            durMs = f.getLong(MediaFormat.KEY_DURATION) / 1000L
                        }
                        break
                    }
                }
                if (!found) throw IOException("El archivo no contiene audio válido")
            } finally {
                try {
                    ex.release()
                } catch (ignored: Exception) {
                }
            }
            seekReq.set(if (startMs > 0) startMs.toLong() else -1L)
        } else {
            val mp = MediaPlayer()
            try {
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                mp.setDataSource(p)
                mp.setOnCompletionListener {
                    state = "ended"
                    releaseWake()
                }
                mp.setOnErrorListener { _, what, extra ->
                    error = "No se pudo reproducir el archivo (código $what/$extra)"
                    state = "error"
                    true
                }
                mp.prepare()
            } catch (e: Exception) {
                try {
                    mp.release()
                } catch (ignored: Exception) {
                }
                throw e
            }
            mp.setVolume(volume, volume)
            if (startMs > 0) mp.seekTo(startMs)
            player = mp
            durMs = mp.duration.toLong()
        }
        state = "ready"
        return durMs
    }

    @Synchronized
    fun play() {
        if (state == "idle") throw IOException("No hay canción cargada")
        acquireWake()
        if (output == "hc05") {
            paused = false
            val w = worker
            if (w == null || !w.isAlive) startWorker()
        } else {
            val mp = player ?: throw IOException("No hay canción cargada")
            if (state == "ended") mp.seekTo(0)
            mp.start()
        }
        state = "playing"
    }

    @Synchronized
    fun pause() {
        if (output == "hc05") {
            paused = true
        } else {
            try {
                player?.pause()
            } catch (ignored: Exception) {
            }
        }
        if (state == "playing") state = "paused"
        releaseWake()
    }

    @Synchronized
    fun stop() {
        release()
        state = "idle"
        posMs = 0L
    }

    @Synchronized
    fun seek(ms: Long) {
        val t = if (ms < 0) 0L else ms
        if (output == "hc05") {
            seekReq.set(t)
        } else {
            try {
                player?.seekTo(t.toInt())
            } catch (ignored: Exception) {
            }
        }
        posMs = t
        if (state == "ended") state = "paused"
    }

    fun setVolume(v: Float) {
        volume = v.coerceIn(0f, 1f)
        try {
            player?.setVolume(volume, volume)
        } catch (ignored: Exception) {
        }
    }

    @Synchronized
    fun status(): Map<String, Any> {
        if (output != "hc05") {
            val mp = player
            if (mp != null && (state == "playing" || state == "paused" || state == "ready")) {
                try {
                    posMs = mp.currentPosition.toLong()
                } catch (ignored: Exception) {
                }
            }
        }
        return mapOf("state" to state, "pos" to posMs, "dur" to durMs, "error" to error)
    }

    // ------------------------------ interno ------------------------------

    private fun release() {
        gen++
        val w = worker
        worker = null
        if (w != null) {
            try {
                w.join(400)
            } catch (ignored: InterruptedException) {
            }
        }
        val mp = player
        player = null
        if (mp != null) {
            try {
                mp.stop()
            } catch (ignored: Exception) {
            }
            try {
                mp.release()
            } catch (ignored: Exception) {
            }
        }
        paused = false
        seekReq.set(-1L)
        releaseWake()
    }

    private fun acquireWake() {
        try {
            if (wake == null) {
                val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
                val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "cozmo:music")
                w.setReferenceCounted(false)
                wake = w
            }
            val w2 = wake
            if (w2 != null && !w2.isHeld) w2.acquire(4L * 60L * 60L * 1000L)
        } catch (e: Exception) {
            // sin permiso: la música igual funciona con la pantalla encendida
        }
    }

    private fun releaseWake() {
        try {
            val w = wake
            if (w != null && w.isHeld) w.release()
        } catch (ignored: Exception) {
        }
    }

    private fun startWorker() {
        val myGen = gen
        val t = Thread { streamLoop(myGen) }
        t.isDaemon = true
        worker = t
        t.start()
    }

    /** Buffer de salida hacia el HC-05 #2 con control de ritmo. */
    private inner class Sink {
        private val buf = ByteArray(256)
        private var n = 0
        private var start = System.nanoTime()
        private var sent = 0L

        fun rebase() {
            start = System.nanoTime()
            sent = 0L
        }

        fun drop() {
            n = 0
        }

        fun put(b: Int) {
            buf[n] = b.toByte()
            n++
            if (n == buf.size) flush()
        }

        fun flush() {
            if (n == 0) return
            val sock = sockets["tx"] ?: throw IOException("El HC-05 #2 se desconectó")
            val o = sock.outputStream
            o.write(buf, 0, n)
            o.flush()
            sent += n.toLong()
            n = 0
            val targetMs = sent * 1000L / rate.toLong()
            val elapsedMs = (System.nanoTime() - start) / 1_000_000L
            val waitMs = targetMs - elapsedMs - 300L // 300 ms de adelanto
            if (waitMs > 0) Thread.sleep(waitMs)
        }

        /** Unos bytes de silencio (nivel medio 128) para no dejar el amplificador en un extremo. */
        fun silence() {
            try {
                val sock = sockets["tx"] ?: return
                val b = ByteArray(64) { 128.toByte() }
                sock.outputStream.write(b)
                sock.outputStream.flush()
            } catch (ignored: Exception) {
            }
        }
    }

    private fun streamLoop(myGen: Int) {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        val sink = Sink()
        try {
            ex.setDataSource(path)
            var track = -1
            var chosen: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    track = i
                    chosen = f
                    break
                }
            }
            val fmt = chosen ?: throw IOException("El archivo no contiene audio válido")
            ex.selectTrack(track)

            val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME) ?: "audio/mpeg")
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()

            var srcRate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var channels = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            if (channels < 1) channels = 1
            var step = srcRate.toDouble() / rate.toDouble()
            var acc = 0.0
            var accW = 0.0

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            while (myGen == gen && !outputDone) {
                // Saltar a otra posición
                val s = seekReq.getAndSet(-1L)
                if (s >= 0L) {
                    ex.seekTo(s * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                    c.flush()
                    inputDone = false
                    acc = 0.0
                    accW = 0.0
                    sink.drop()
                    sink.rebase()
                    posMs = s
                }

                // Pausa
                if (paused) {
                    sink.drop()
                    sink.silence()
                    while (paused && myGen == gen && seekReq.get() < 0L) {
                        Thread.sleep(40)
                    }
                    sink.rebase()
                    continue
                }

                // Entrada al decodificador
                if (!inputDone) {
                    val inIdx = c.dequeueInputBuffer(5_000L)
                    if (inIdx >= 0) {
                        val ib = c.getInputBuffer(inIdx)
                        val size = if (ib != null) ex.readSampleData(ib, 0) else -1
                        if (size < 0) {
                            c.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(inIdx, 0, size, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }

                // Salida: PCM 16 bits -> mono -> remuestreo (promedio) -> 8 bits sin signo
                val oi = c.dequeueOutputBuffer(info, 5_000L)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = c.outputFormat
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) srcRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (channels < 1) channels = 1
                    step = srcRate.toDouble() / rate.toDouble()
                } else if (oi >= 0) {
                    val ob = c.getOutputBuffer(oi)
                    if (ob != null && info.size > 0) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val sb = ob.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        val frames = sb.remaining() / channels
                        val g = volume
                        for (f in 0 until frames) {
                            var sum = 0f
                            for (ch in 0 until channels) sum += sb.get().toFloat()
                            val x = sum / (channels.toFloat() * 32768f)
                            var w = 1.0
                            while (w > 1e-9) {
                                val need = step - accW
                                if (w >= need) {
                                    acc += x * need
                                    var v = (acc / step).toFloat() * g
                                    if (v > 1f) v = 1f
                                    if (v < -1f) v = -1f
                                    sink.put((128f + v * 127f).toInt())
                                    acc = 0.0
                                    accW = 0.0
                                    w -= need
                                } else {
                                    acc += x * w
                                    accW += w
                                    w = 0.0
                                }
                            }
                        }
                        posMs = info.presentationTimeUs / 1000L
                    }
                    c.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                }
            }

            if (myGen == gen && outputDone) {
                sink.flush()
                state = "ended"
                releaseWake()
            }
        } catch (e: InterruptedException) {
            // cancelado
        } catch (e: Exception) {
            if (myGen == gen) {
                error = e.message ?: "Error al enviar la música al HC-05 #2"
                state = "error"
                releaseWake()
            }
        } finally {
            try {
                codec?.stop()
            } catch (ignored: Exception) {
            }
            try {
                codec?.release()
            } catch (ignored: Exception) {
            }
            try {
                ex.release()
            } catch (ignored: Exception) {
            }
            sink.silence()
        }
    }
}
