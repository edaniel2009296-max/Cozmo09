import 'dart:math' as math;
import 'dart:typed_data';

/// Conversión de audio entre el formato del robot (PCM 8 bits sin signo, mono)
/// y los formatos que usan el celular y la IA.
class AudioUtils {
  /// Nivel de energía (desviación media) de un bloque PCM 8 bits.
  static double level(Uint8List c) {
    if (c.isEmpty) return 0;
    var sum = 0;
    for (final v in c) {
      sum += v;
    }
    final mean = sum / c.length;
    var dev = 0.0;
    for (final v in c) {
      dev += (v - mean).abs();
    }
    return dev / c.length;
  }

  /// PCM 8 bits sin signo -> WAV 16 bits (quita el offset DC y normaliza el volumen).
  static Uint8List pcm8ToWav(Uint8List pcm8, int sampleRate) {
    final n = pcm8.length;
    var sum = 0;
    for (final v in pcm8) {
      sum += v;
    }
    final mean = n == 0 ? 128.0 : sum / n;
    var peak = 1.0;
    for (final v in pcm8) {
      final d = (v - mean).abs();
      if (d > peak) peak = d;
    }
    final gain = math.min(40.0, 100.0 / peak);

    final dataLen = n * 2;
    final out = ByteData(44 + dataLen);
    void str(int off, String s) {
      for (var i = 0; i < s.length; i++) {
        out.setUint8(off + i, s.codeUnitAt(i));
      }
    }

    str(0, 'RIFF');
    out.setUint32(4, 36 + dataLen, Endian.little);
    str(8, 'WAVE');
    str(12, 'fmt ');
    out.setUint32(16, 16, Endian.little);
    out.setUint16(20, 1, Endian.little); // PCM
    out.setUint16(22, 1, Endian.little); // mono
    out.setUint32(24, sampleRate, Endian.little);
    out.setUint32(28, sampleRate * 2, Endian.little);
    out.setUint16(32, 2, Endian.little);
    out.setUint16(34, 16, Endian.little);
    str(36, 'data');
    out.setUint32(40, dataLen, Endian.little);

    for (var i = 0; i < n; i++) {
      var s = ((pcm8[i] - mean) * gain * 256).round();
      s = math.max(-32768, math.min(32767, s));
      out.setInt16(44 + i * 2, s, Endian.little);
    }
    return out.buffer.asUint8List();
  }

  /// WAV 16 bits (lo que genera el TTS de Android) -> PCM 8 bits sin signo, mono,
  /// a la frecuencia [targetRate]. Devuelve null si el WAV no es válido.
  static Uint8List? wavToPcm8(Uint8List wav, int targetRate) {
    if (wav.length < 44) return null;
    final bd = ByteData.sublistView(wav);
    String tag(int o) => String.fromCharCodes(wav.sublist(o, o + 4));
    if (tag(0) != 'RIFF' || tag(8) != 'WAVE') return null;

    var pos = 12;
    int? rate;
    int? channels;
    int? bits;
    var dataStart = -1;
    var dataLen = 0;
    while (pos + 8 <= wav.length) {
      final id = tag(pos);
      var size = bd.getUint32(pos + 4, Endian.little);
      final body = pos + 8;
      if (id == 'fmt ') {
        channels = bd.getUint16(body + 2, Endian.little);
        rate = bd.getUint32(body + 4, Endian.little);
        bits = bd.getUint16(body + 14, Endian.little);
      } else if (id == 'data') {
        final remaining = wav.length - body;
        if (size == 0 || size > remaining) size = remaining;
        dataStart = body;
        dataLen = size;
        break;
      }
      pos = body + size + (size & 1);
    }
    if (rate == null || channels == null || bits != 16 || dataStart < 0) {
      return null;
    }
    if (channels < 1 || rate < 1) return null;

    final int chCount = channels;
    final int srcRate = rate;
    final int start = dataStart;
    final frames = dataLen ~/ (2 * chCount);
    if (frames <= 0) return null;

    double sampleAt(int frame) {
      var acc = 0;
      for (var c = 0; c < chCount; c++) {
        acc += bd.getInt16(start + (frame * chCount + c) * 2, Endian.little);
      }
      return acc / chCount;
    }

    final ratio = srcRate / targetRate;
    final outLen = (frames / ratio).floor();
    final out = Uint8List(outLen);
    for (var i = 0; i < outLen; i++) {
      final s = (i * ratio).floor();
      var e = ((i + 1) * ratio).floor();
      if (e <= s) e = s + 1;
      if (e > frames) e = frames;
      var acc = 0.0;
      var count = 0;
      for (var j = s; j < e; j++) {
        acc += sampleAt(j);
        count++;
      }
      final avg = count == 0 ? 0.0 : acc / count;
      final v = (avg / 256).round() + 128;
      out[i] = math.max(0, math.min(255, v));
    }
    return out;
  }
}
