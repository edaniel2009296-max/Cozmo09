import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

enum WsState { disconnected, connecting, connected }

/// Conexión WebSocket con el NodeMCU (OLED y servos).
class WebSocketManager {
  static final ValueNotifier<WsState> state = ValueNotifier(WsState.disconnected);
  static final ValueNotifier<String> lastMessage = ValueNotifier('');

  static WebSocketChannel? _channel;
  static StreamSubscription? _sub;

  static bool get isConnected => state.value == WsState.connected;

  /// Devuelve null si conectó bien, o un mensaje de error.
  static Future<String?> connect(String host, {int port = 81}) async {
    await disconnect();

    var h = host.trim();
    h = h.replaceFirst(RegExp(r'^(ws|wss|http|https)://'), '');
    h = h.split('/').first;
    if (h.contains(':')) {
      final parts = h.split(':');
      h = parts.first;
      port = int.tryParse(parts.last) ?? port;
    }
    if (h.isEmpty) return 'Escribe la IP del NodeMCU';

    state.value = WsState.connecting;
    WebSocketChannel? ch;
    try {
      ch = IOWebSocketChannel.connect(
        Uri.parse('ws://$h:$port'),
        pingInterval: const Duration(seconds: 20),
      );
      await ch.ready.timeout(const Duration(seconds: 6));
      final connected = ch;
      _channel = connected;
      _sub = connected.stream.listen(
        (m) => lastMessage.value = m.toString(),
        onDone: () => _closed(connected),
        onError: (_) => _closed(connected),
        cancelOnError: true,
      );
      state.value = WsState.connected;
      return null;
    } catch (e) {
      try {
        ch?.sink.close();
      } catch (_) {}
      state.value = WsState.disconnected;
      return 'No se pudo conectar a ws://$h:$port. Revisa que el celular esté en '
          'el mismo WiFi que el NodeMCU y que la IP sea correcta.';
    }
  }

  static void _closed(WebSocketChannel ch) {
    if (identical(_channel, ch)) {
      _channel = null;
      state.value = WsState.disconnected;
    }
  }

  static Future<void> disconnect() async {
    await _sub?.cancel();
    _sub = null;
    final ch = _channel;
    _channel = null;
    try {
      ch?.sink.close();
    } catch (_) {}
    state.value = WsState.disconnected;
  }

  /// Envía un comando de texto al NodeMCU. Devuelve false si no hay conexión.
  static bool sendCommand(String command) {
    final ch = _channel;
    if (ch == null || !isConnected) return false;
    try {
      ch.sink.add(command);
      return true;
    } catch (_) {
      return false;
    }
  }
}
