import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

typedef JoystickCallback = void Function(double x, double y);

/// Joystick táctil. Usa eventos crudos del dedo, así que varios joysticks funcionan
/// a la vez (uno por pulgar) y responden sin retraso. Al soltar vuelve al centro.
/// x: -1 (izquierda) a 1 (derecha) · y: -1 (abajo) a 1 (arriba)
class Joystick extends StatefulWidget {
  final double size;
  final bool lockX; // solo eje horizontal (dirección)
  final bool lockY; // solo eje vertical (acelerador / orugas)
  final JoystickCallback onChanged;

  const Joystick({
    super.key,
    required this.size,
    required this.onChanged,
    this.lockX = false,
    this.lockY = false,
  });

  @override
  State<Joystick> createState() => _JoystickState();
}

class _JoystickState extends State<Joystick> {
  Offset _v = Offset.zero; // normalizado, y hacia abajo (como la pantalla)
  int? _pointer;

  double get _travel => widget.size / 2 * 0.64;

  void _apply(Offset local) {
    final c = Offset(widget.size / 2, widget.size / 2);
    var d = (local - c) / _travel;
    if (widget.lockX) d = Offset(d.dx, 0);
    if (widget.lockY) d = Offset(0, d.dy);
    final len = d.distance;
    if (len > 1) d = d / len;
    setState(() => _v = d);
    widget.onChanged(d.dx, -d.dy);
  }

  void _release() {
    _pointer = null;
    setState(() => _v = Offset.zero);
    widget.onChanged(0, 0);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: (e) {
          if (_pointer != null) return;
          _pointer = e.pointer;
          HapticFeedback.lightImpact();
          _apply(e.localPosition);
        },
        onPointerMove: (e) {
          if (e.pointer == _pointer) _apply(e.localPosition);
        },
        onPointerUp: (e) {
          if (e.pointer == _pointer) _release();
        },
        onPointerCancel: (e) {
          if (e.pointer == _pointer) _release();
        },
        child: CustomPaint(
          size: Size.square(widget.size),
          painter: _JoyPainter(
            v: _v,
            lockX: widget.lockX,
            lockY: widget.lockY,
            travel: _travel,
            knob: cs.primary,
            base: cs.surfaceContainerHighest,
            ring: cs.outline,
          ),
        ),
      ),
    );
  }
}

class _JoyPainter extends CustomPainter {
  final Offset v;
  final bool lockX;
  final bool lockY;
  final double travel;
  final Color knob;
  final Color base;
  final Color ring;

  _JoyPainter({
    required this.v,
    required this.lockX,
    required this.lockY,
    required this.travel,
    required this.knob,
    required this.base,
    required this.ring,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2 * 0.96;
    final fill = Paint()..color = base;
    final stroke = Paint()
      ..color = ring.withAlpha(150)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    if (lockX || lockY) {
      final w = lockX ? r * 2 : r * 0.7;
      final h = lockY ? r * 2 : r * 0.7;
      final rr = RRect.fromRectAndRadius(
        Rect.fromCenter(center: c, width: w, height: h),
        Radius.circular(r * 0.35),
      );
      canvas.drawRRect(rr, fill);
      canvas.drawRRect(rr, stroke);
    } else {
      canvas.drawCircle(c, r, fill);
      canvas.drawCircle(c, r, stroke);
      canvas.drawCircle(c, travel, stroke..strokeWidth = 1);
    }

    // marcas de centro
    final tick = Paint()
      ..color = ring.withAlpha(110)
      ..strokeWidth = 1.5;
    canvas.drawLine(Offset(c.dx - 8, c.dy), Offset(c.dx + 8, c.dy), tick);
    canvas.drawLine(Offset(c.dx, c.dy - 8), Offset(c.dx, c.dy + 8), tick);

    final k = c + Offset(v.dx * travel, v.dy * travel);
    final active = v.distance > 0.02;
    canvas.drawCircle(k, size.width * 0.17 + 4, Paint()..color = knob.withAlpha(active ? 70 : 30));
    canvas.drawCircle(k, size.width * 0.17, Paint()..color = knob.withAlpha(active ? 255 : 200));
  }

  @override
  bool shouldRepaint(covariant _JoyPainter old) =>
      old.v != v ||
      old.lockX != lockX ||
      old.lockY != lockY ||
      old.knob != knob ||
      old.base != base;
}
