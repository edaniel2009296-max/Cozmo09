import 'package:shared_preferences/shared_preferences.dart';

/// Qué se envía al HC-05 #2 cuando el robot "habla".
enum TxMode { audio, text }

/// Ajustes guardados en el celular (sobreviven al cerrar la app).
class AppSettings {
  static late SharedPreferences _p;

  static Future<void> init() async {
    _p = await SharedPreferences.getInstance();
  }

  static String _s(String k) => _p.getString(k) ?? '';

  // ---- NodeMCU (WiFi) ----
  static String get nodeIp => _s('nodeIp');
  static set nodeIp(String v) {
    _p.setString('nodeIp', v);
  }

  static int get nodePort => _p.getInt('nodePort') ?? 81;
  static set nodePort(int v) {
    _p.setInt('nodePort', v);
  }

  // ---- HC-05 #1 (micrófono del robot -> app) ----
  static String get rxAddress => _s('rxAddress');
  static set rxAddress(String v) {
    _p.setString('rxAddress', v);
  }

  static String get rxName => _s('rxName');
  static set rxName(String v) {
    _p.setString('rxName', v);
  }

  // ---- HC-05 #2 (app -> altavoz del robot) ----
  static String get txAddress => _s('txAddress');
  static set txAddress(String v) {
    _p.setString('txAddress', v);
  }

  static String get txName => _s('txName');
  static set txName(String v) {
    _p.setString('txName', v);
  }

  // ---- IA ----
  static String get geminiKey => _s('geminiKey');
  static set geminiKey(String v) {
    _p.setString('geminiKey', v);
  }

  /// Modelo de Gemini forzado a mano (vacío = automático).
  static String get geminiModel => _s('geminiModel');
  static set geminiModel(String v) {
    _p.setString('geminiModel', v);
  }

  /// Último modelo que respondió bien (cache interno).
  static String get workingModel => _s('workingModel');
  static set workingModel(String v) {
    _p.setString('workingModel', v);
  }

  // ---- Audio ----
  /// Frecuencia de muestreo del audio PCM 8 bits que usa el robot.
  static int get sampleRate => _p.getInt('sampleRate') ?? 8000;
  static set sampleRate(int v) {
    _p.setInt('sampleRate', v);
  }

  static TxMode get txMode =>
      (_p.getInt('txMode') ?? 0) == 1 ? TxMode.text : TxMode.audio;
  static set txMode(TxMode v) {
    _p.setInt('txMode', v == TxMode.text ? 1 : 0);
  }

  static bool get speakOnPhone => _p.getBool('speakOnPhone') ?? true;
  static set speakOnPhone(bool v) {
    _p.setBool('speakOnPhone', v);
  }

  /// 'phone' o 'robot'
  static String get micSource => _p.getString('micSource') ?? 'phone';
  static set micSource(String v) {
    _p.setString('micSource', v);
  }

  // ======================= Conducción (nuevo) =======================

  /// 0 = arcade (1 joystick), 1 = tanque (2 joysticks), 2 = auto (dirección + acelerador)
  static int get driveMode => _p.getInt('driveMode') ?? 0;
  static set driveMode(int v) {
    _p.setInt('driveMode', v);
  }

  /// Velocidad máxima (0.1 a 1.0)
  static double get maxSpeed => _p.getDouble('maxSpeed') ?? 0.6;
  static set maxSpeed(double v) {
    _p.setDouble('maxSpeed', v);
  }

  static bool get invert1 => _p.getBool('invert1') ?? false;
  static set invert1(bool v) {
    _p.setBool('invert1', v);
  }

  static bool get invert2 => _p.getBool('invert2') ?? false;
  static set invert2(bool v) {
    _p.setBool('invert2', v);
  }

  /// Intercambia qué servo es el "izquierdo" y cuál el "derecho".
  static bool get swapMotors => _p.getBool('swapMotors') ?? false;
  static set swapMotors(bool v) {
    _p.setBool('swapMotors', v);
  }

  /// Curva de sensibilidad (1.0 = lineal, mayor = más fino cerca del centro).
  static double get driveExpo => _p.getDouble('driveExpo') ?? 1.4;
  static set driveExpo(double v) {
    _p.setDouble('driveExpo', v);
  }

  static double get touchDeadzone => _p.getDouble('touchDeadzone') ?? 0.06;
  static set touchDeadzone(double v) {
    _p.setDouble('touchDeadzone', v);
  }

  static double get padDeadzone => _p.getDouble('padDeadzone') ?? 0.12;
  static set padDeadzone(double v) {
    _p.setDouble('padDeadzone', v);
  }

  /// Grados mínimos desde 90 para que el servo arranque (salta la zona muerta del servo).
  static double get driveMinStart => _p.getDouble('driveMinStart') ?? 0;
  static set driveMinStart(double v) {
    _p.setDouble('driveMinStart', v);
  }

  /// Grados máximos desde 90 (90 = servo de 0° a 180°).
  static double get driveRange => _p.getDouble('driveRange') ?? 90;
  static set driveRange(double v) {
    _p.setDouble('driveRange', v);
  }

  /// Segundos para llegar a máxima velocidad (0 = instantáneo).
  static double get driveRampSec => _p.getDouble('driveRampSec') ?? 0.3;
  static set driveRampSec(double v) {
    _p.setDouble('driveRampSec', v);
  }

  /// Intercambia los lados de los controles en pantalla.
  static bool get leftHanded => _p.getBool('leftHanded') ?? false;
  static set leftHanded(bool v) {
    _p.setBool('leftHanded', v);
  }

  static bool get padEnabled => _p.getBool('padEnabled') ?? true;
  static set padEnabled(bool v) {
    _p.setBool('padEnabled', v);
  }

  static bool get keepAwake => _p.getBool('keepAwake') ?? true;
  static set keepAwake(bool v) {
    _p.setBool('keepAwake', v);
  }

  // ========================== Música (nuevo) ==========================

  /// 'phone' = audio normal del celular (parlante Bluetooth A2DP o altavoz)
  /// 'hc05'  = por el HC-05 #2 hacia el amplificador del robot
  static String get musicOutput => _p.getString('musicOutput') ?? 'phone';
  static set musicOutput(String v) {
    _p.setString('musicOutput', v);
  }

  static double get musicVolume => _p.getDouble('musicVolume') ?? 0.8;
  static set musicVolume(double v) {
    _p.setDouble('musicVolume', v);
  }

  static List<String> get musicPlaylist => _p.getStringList('musicPlaylist') ?? <String>[];
  static set musicPlaylist(List<String> v) {
    _p.setStringList('musicPlaylist', v);
  }
}
