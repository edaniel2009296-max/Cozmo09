import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'app_settings.dart';
import 'drive_controller.dart';
import 'music_manager.dart';
import 'system_bridge.dart';
import 'websocket_manager.dart';

/// Gamepad Bluetooth (Xbox, PS4/PS5, 8BitDo, genéricos...).
/// El gamepad se empareja desde los ajustes Bluetooth del celular (como unos audífonos);
/// la parte nativa (MainActivity.kt) recibe sticks y botones y los manda aquí.
///
/// Mapa de botones (estándar Android):
///   Stick izq. / der. / gatillos ... conducir (según el modo)
///   A ^_^   B T_T   X O_o   Y >_<   ... cara en el OLED
///   L1 / R1 ... bajar / subir velocidad máxima
///   Start ... STOP de emergencia        Select ... cambiar modo de conducción
///   L3 (clic stick izq.) ... play/pausa música
///   Cruceta ↑ ↓ ... volumen música      Cruceta ← → ... canción anterior / siguiente
class GamepadManager {
  GamepadManager._();

  static const EventChannel _events = EventChannel('cozmo/gamepad');

  static final ValueNotifier<List<String>> devices = ValueNotifier<List<String>>(<String>[]);
  static final ValueNotifier<String> lastButton = ValueNotifier<String>('');

  static bool _started = false;
  static double _hx = 0;
  static double _hy = 0;
  static DateTime _lastKeyDpad = DateTime.fromMillisecondsSinceEpoch(0);
  static DateTime _lastHat = DateTime.fromMillisecondsSinceEpoch(0);

  static void init() {
    if (_started) return;
    _started = true;
    _events.receiveBroadcastStream().listen(_onEvent, onError: (Object e) {
      debugPrint('Gamepad events error: $e');
    });
  }

  static void setEnabled(bool v) {
    AppSettings.padEnabled = v;
    if (!v) DriveController.padInput(0, 0, 0, 0, 0, 0);
  }

  static Future<void> openBluetoothSettings() => SystemBridge.openBluetoothSettings();

  static void _onEvent(dynamic event) {
    if (event is! Map) return;
    final type = event['type'];
    if (type == 'devices') {
      final raw = event['names'];
      final names = raw is List ? raw.map((e) => e.toString()).toList() : <String>[];
      devices.value = names;
      if (names.isEmpty) DriveController.padInput(0, 0, 0, 0, 0, 0);
    } else if (type == 'axes') {
      _onAxes(event['v']);
    } else if (type == 'button') {
      final code = event['code'];
      if (code is num) _onButton(code.toInt(), event['down'] == true);
    }
  }

  static void _onAxes(dynamic v) {
    if (v is! List || v.length < 8) return;
    final a = v.map((e) => (e as num).toDouble()).toList();
    if (!AppSettings.padEnabled) return;
    DriveController.padInput(a[0], a[1], a[2], a[3], a[4], a[5]);
    _onHat(a[6], a[7]);
  }

  static int _dir(double v) => v > 0.5 ? 1 : (v < -0.5 ? -1 : 0);

  // Algunos gamepads mandan la cruceta como ejes (hat) y otros como teclas.
  static void _onHat(double hx, double hy) {
    final nx = _dir(hx);
    final ny = _dir(hy);
    final ox = _dir(_hx);
    final oy = _dir(_hy);
    _hx = hx;
    _hy = hy;
    final now = DateTime.now();
    if (nx != ox || ny != oy) _lastHat = now;
    if (now.difference(_lastKeyDpad).inMilliseconds < 150) return;
    if (nx != ox && nx != 0) _action(nx < 0 ? 21 : 22);
    if (ny != oy && ny != 0) _action(ny < 0 ? 19 : 20);
  }

  static void _onButton(int code, bool down) {
    if (!down) return;
    final isDpad = code >= 19 && code <= 22;
    if (isDpad) {
      final now = DateTime.now();
      if (now.difference(_lastHat).inMilliseconds < 150) return;
      _lastKeyDpad = now;
    }
    _action(code);
  }

  static void _face(String f) {
    WebSocketManager.sendCommand('FACE:$f|TEXT:');
  }

  static void _action(int code) {
    if (!AppSettings.padEnabled) return;
    lastButton.value = _name(code);
    switch (code) {
      case 96: // A
        _face('^_^');
        break;
      case 97: // B
        _face('T_T');
        break;
      case 99: // X
        _face('O_o');
        break;
      case 100: // Y
        _face('>_<');
        break;
      case 102: // L1
        DriveController.setMaxSpeed(DriveController.maxSpeed.value - 0.1);
        break;
      case 103: // R1
        DriveController.setMaxSpeed(DriveController.maxSpeed.value + 0.1);
        break;
      case 108: // Start
        DriveController.stop();
        break;
      case 109: // Select
        DriveController.cycleMode();
        break;
      case 106: // L3
        MusicManager.togglePlay();
        break;
      case 19: // cruceta arriba
        MusicManager.changeVolume(0.05);
        break;
      case 20: // cruceta abajo
        MusicManager.changeVolume(-0.05);
        break;
      case 21: // cruceta izquierda
        MusicManager.prev();
        break;
      case 22: // cruceta derecha
        MusicManager.next();
        break;
    }
  }

  static String _name(int code) {
    switch (code) {
      case 96:
        return 'A';
      case 97:
        return 'B';
      case 99:
        return 'X';
      case 100:
        return 'Y';
      case 102:
        return 'L1';
      case 103:
        return 'R1';
      case 104:
        return 'L2';
      case 105:
        return 'R2';
      case 106:
        return 'L3';
      case 107:
        return 'R3';
      case 108:
        return 'Start';
      case 109:
        return 'Select';
      case 19:
        return '↑';
      case 20:
        return '↓';
      case 21:
        return '←';
      case 22:
        return '→';
      default:
        return 'Botón $code';
    }
  }
}
