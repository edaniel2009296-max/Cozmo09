import 'package:flutter/material.dart';

import '../ai_service.dart';
import '../app_settings.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final TextEditingController _key = TextEditingController(text: AppSettings.geminiKey);
  final TextEditingController _model = TextEditingController(text: AppSettings.geminiModel);
  bool _hideKey = true;
  bool _testing = false;
  String _testResult = '';
  bool _testOk = false;

  @override
  void dispose() {
    _key.dispose();
    _model.dispose();
    super.dispose();
  }

  Future<void> _testAI() async {
    setState(() {
      _testing = true;
      _testResult = '';
    });
    try {
      AIService.clearHistory();
      final r = await AIService.ask('Salúdame en una frase corta.');
      if (!mounted) return;
      setState(() {
        _testOk = true;
        _testResult = '${r.provider}\n${r.text}';
      });
    } on AIException catch (e) {
      if (!mounted) return;
      setState(() {
        _testOk = false;
        _testResult = e.message;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _testOk = false;
        _testResult = 'Error: $e';
      });
    } finally {
      AIService.clearHistory();
      if (mounted) setState(() => _testing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Inteligencia artificial (gratis)', style: theme.textTheme.titleMedium),
          const SizedBox(height: 6),
          Text(
            'Sin clave la app usa un servicio gratuito sin registro (puede ser más lento o '
            'dejar de estar disponible). Para mejor calidad y para usar el micrófono del robot, '
            'crea una API key GRATIS de Gemini en aistudio.google.com/apikey (con tu cuenta '
            'de Google, sin tarjeta) y pégala aquí.',
            style: theme.textTheme.bodySmall,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _key,
            obscureText: _hideKey,
            autocorrect: false,
            enableSuggestions: false,
            onChanged: (v) => AppSettings.geminiKey = v.trim(),
            decoration: InputDecoration(
              labelText: 'API key de Gemini',
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(
                icon: Icon(_hideKey ? Icons.visibility : Icons.visibility_off),
                onPressed: () => setState(() => _hideKey = !_hideKey),
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _model,
            autocorrect: false,
            onChanged: (v) {
              AppSettings.geminiModel = v.trim();
              AppSettings.workingModel = '';
            },
            decoration: const InputDecoration(
              labelText: 'Modelo de Gemini (opcional)',
              helperText: 'Déjalo vacío: la app elige el mejor modelo gratuito automáticamente.',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _testing ? null : _testAI,
            icon: _testing
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.bolt),
            label: Text(_testing ? 'Probando…' : 'Probar IA'),
          ),
          if (_testResult.isNotEmpty) ...[
            const SizedBox(height: 8),
            Card(
              color: _testOk
                  ? theme.colorScheme.primaryContainer
                  : theme.colorScheme.errorContainer,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(_testResult),
              ),
            ),
          ],
          const Divider(height: 40),
          Text('Voz y audio del robot', style: theme.textTheme.titleMedium),
          const SizedBox(height: 12),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Hablar en el celular'),
            subtitle: const Text('Reproduce la respuesta por el altavoz del celular.'),
            value: AppSettings.speakOnPhone,
            onChanged: (v) => setState(() => AppSettings.speakOnPhone = v),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<TxMode>(
            value: AppSettings.txMode,
            decoration: const InputDecoration(
              labelText: 'Qué enviar al HC-05 #2',
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(
                value: TxMode.audio,
                child: Text('Audio (PCM 8 bits)'),
              ),
              DropdownMenuItem(
                value: TxMode.text,
                child: Text('Solo texto'),
              ),
            ],
            onChanged: (v) {
              if (v != null) setState(() => AppSettings.txMode = v);
            },
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<int>(
            value: AppSettings.sampleRate,
            decoration: const InputDecoration(
              labelText: 'Frecuencia de muestreo del audio',
              helperText: 'Debe coincidir con el robot (audio mono de 8 bits sin signo).',
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: 8000, child: Text('8000 Hz')),
              DropdownMenuItem(value: 11025, child: Text('11025 Hz')),
              DropdownMenuItem(value: 16000, child: Text('16000 Hz')),
            ],
            onChanged: (v) {
              if (v != null) setState(() => AppSettings.sampleRate = v);
            },
          ),
        ],
      ),
    );
  }
}
