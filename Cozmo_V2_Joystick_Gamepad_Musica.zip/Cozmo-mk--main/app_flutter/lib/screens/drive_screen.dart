import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../app_settings.dart';
import '../drive_controller.dart';
import '../gamepad_manager.dart';
import '../system_bridge.dart';
import '../websocket_manager.dart';
import '../widgets/joystick.dart';
import 'servo_screen.dart';

/// Pestaña "Conducir": joystick táctil, modo tanque, modo auto y gamepad Bluetooth.
/// El modo "Servos" es la pantalla de siempre (D-pad y sliders), sin cambios.
class DriveScreen extends StatefulWidget {
  const DriveScreen({super.key});
  @override
  State<DriveScreen> createState() => _DriveScreenState();
}

class _DriveScreenState extends State<DriveScreen> {
  bool _manual = false;

  void _openFull() {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const DriveFullScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(12, 8, 12, 0),
          child: Align(alignment: Alignment.centerLeft, child: _StatusChips()),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
          child: ValueListenableBuilder<DriveMode>(
            valueListenable: DriveController.mode,
            builder: (_, m, __) => SegmentedButton<int>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: 0, label: Text('Arcade')),
                ButtonSegment(value: 1, label: Text('Tanque')),
                ButtonSegment(value: 2, label: Text('Auto')),
                ButtonSegment(value: 3, label: Text('Servos')),
              ],
              selected: {_manual ? 3 : m.index},
              onSelectionChanged: (s) {
                final v = s.first;
                if (v == 3) {
                  DriveController.stop();
                  setState(() => _manual = true);
                } else {
                  setState(() => _manual = false);
                  DriveController.setMode(DriveMode.values[v]);
                }
              },
            ),
          ),
        ),
        Expanded(
          child: _manual
              ? const ServoScreen()
              : const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 12),
                  child: DriveSurface(landscape: false),
                ),
        ),
        if (!_manual) ...[
          const Padding(
            padding: EdgeInsets.fromLTRB(12, 0, 12, 0),
            child: _Telemetry(),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(12, 0, 12, 0),
            child: _SpeedRow(),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
            child: Row(
              children: [
                const Expanded(child: _StopButton()),
                const SizedBox(width: 8),
                IconButton.filledTonal(
                  tooltip: 'Pantalla completa (horizontal)',
                  onPressed: _openFull,
                  icon: const Icon(Icons.fullscreen),
                ),
                IconButton.filledTonal(
                  tooltip: 'Ajustes de conducción y gamepad',
                  onPressed: () => showDriveSettings(context),
                  icon: const Icon(Icons.tune),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Superficie de control: arma los joysticks según el modo
// ---------------------------------------------------------------------------

class DriveSurface extends StatefulWidget {
  final bool landscape;
  const DriveSurface({super.key, required this.landscape});
  @override
  State<DriveSurface> createState() => _DriveSurfaceState();
}

class _DriveSurfaceState extends State<DriveSurface> {
  double _ax = 0;
  double _ay = 0;
  double _bx = 0;
  double _by = 0;

  void _push() => DriveController.touchInput(_ax, _ay, _bx, _by);

  Widget _joy(double size, String label,
      {bool lockX = false, bool lockY = false, required JoystickCallback onChanged}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Joystick(size: size, lockX: lockX, lockY: lockY, onChanged: onChanged),
        const SizedBox(height: 4),
        Text(label, style: Theme.of(context).textTheme.labelMedium),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: DriveController.revision,
      builder: (_, __, ___) => ValueListenableBuilder<DriveMode>(
      valueListenable: DriveController.mode,
      builder: (_, m, __) => LayoutBuilder(
        builder: (context, c) {
          final w = c.maxWidth;
          final h = c.maxHeight - 28; // espacio de la etiqueta
          final left = AppSettings.leftHanded;

          if (m == DriveMode.arcade) {
            final s = math.max(80.0, math.min(h, math.min(widget.landscape ? w * 0.5 : w, 340.0)));
            final joy = _joy(s, 'Mover', onChanged: (x, y) {
              _ax = x;
              _ay = y;
              _push();
            });
            if (!widget.landscape) return Center(child: joy);
            final speed = SizedBox(
              width: 90,
              height: math.max(80.0, h),
              child: const _VerticalSpeed(),
            );
            return Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: left ? [joy, speed] : [speed, joy],
            );
          }

          final s = math.max(80.0, math.min(h, math.min((w - 24) / 2, 280.0)));
          final isCar = m == DriveMode.car;
          final a = _joy(
            s,
            isCar ? 'Dirección' : 'Izquierda',
            lockX: isCar,
            lockY: !isCar,
            onChanged: (x, y) {
              _ax = x;
              _ay = y;
              _push();
            },
          );
          final b = _joy(
            s,
            isCar ? 'Acelerador' : 'Derecha',
            lockY: true,
            onChanged: (x, y) {
              _bx = x;
              _by = y;
              _push();
            },
          );
          final swap = isCar && left;
          return Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: swap ? [b, a] : [a, b],
          );
        },
      ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Piezas pequeñas
// ---------------------------------------------------------------------------

class _StatusChips extends StatelessWidget {
  const _StatusChips();

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      children: [
        ValueListenableBuilder<WsState>(
          valueListenable: WebSocketManager.state,
          builder: (_, st, __) {
            final ok = st == WsState.connected;
            return Chip(
              visualDensity: VisualDensity.compact,
              avatar: Icon(Icons.wifi, size: 16, color: ok ? Colors.green : Colors.red),
              label: Text(ok ? 'NodeMCU conectado' : 'NodeMCU desconectado'),
            );
          },
        ),
        ValueListenableBuilder<List<String>>(
          valueListenable: GamepadManager.devices,
          builder: (_, names, __) {
            final ok = names.isNotEmpty;
            return Chip(
              visualDensity: VisualDensity.compact,
              avatar: Icon(Icons.sports_esports, size: 16, color: ok ? Colors.green : Colors.grey),
              label: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 170),
                child: Text(ok ? names.first : 'Sin gamepad', overflow: TextOverflow.ellipsis),
              ),
            );
          },
        ),
      ],
    );
  }
}

class _StatusIcons extends StatelessWidget {
  const _StatusIcons();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        ValueListenableBuilder<WsState>(
          valueListenable: WebSocketManager.state,
          builder: (_, st, __) => Tooltip(
            message: st == WsState.connected ? 'NodeMCU conectado' : 'NodeMCU desconectado',
            child: Icon(Icons.wifi,
                color: st == WsState.connected ? Colors.green : Colors.red),
          ),
        ),
        const SizedBox(width: 10),
        ValueListenableBuilder<List<String>>(
          valueListenable: GamepadManager.devices,
          builder: (_, names, __) => Tooltip(
            message: names.isEmpty ? 'Sin gamepad' : names.first,
            child: Icon(Icons.sports_esports,
                color: names.isEmpty ? Colors.grey : Colors.green),
          ),
        ),
      ],
    );
  }
}

class _Telemetry extends StatelessWidget {
  const _Telemetry();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<DriveOutput>(
      valueListenable: DriveController.output,
      builder: (_, o, __) => Text(
        'Izq ${(o.left * 100).round()}%  ·  Der ${(o.right * 100).round()}%   '
        '(servo 1: ${o.servo1}°  servo 2: ${o.servo2}°)',
        style: Theme.of(context).textTheme.bodySmall,
        textAlign: TextAlign.center,
      ),
    );
  }
}

class _SpeedRow extends StatelessWidget {
  const _SpeedRow();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<double>(
      valueListenable: DriveController.maxSpeed,
      builder: (_, v, __) => Row(
        children: [
          const Icon(Icons.speed),
          Expanded(
            child: Slider(
              min: 0.1,
              max: 1.0,
              divisions: 18,
              value: v,
              label: '${(v * 100).round()}%',
              onChanged: DriveController.setMaxSpeed,
            ),
          ),
          SizedBox(width: 44, child: Text('${(v * 100).round()}%')),
        ],
      ),
    );
  }
}

class _VerticalSpeed extends StatelessWidget {
  const _VerticalSpeed();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<double>(
      valueListenable: DriveController.maxSpeed,
      builder: (_, v, __) => Column(
        children: [
          const Icon(Icons.speed),
          Expanded(
            child: RotatedBox(
              quarterTurns: 3,
              child: Slider(
                min: 0.1,
                max: 1.0,
                divisions: 18,
                value: v,
                label: '${(v * 100).round()}%',
                onChanged: DriveController.setMaxSpeed,
              ),
            ),
          ),
          Text('${(v * 100).round()}%'),
        ],
      ),
    );
  }
}

class _StopButton extends StatelessWidget {
  const _StopButton();

  @override
  Widget build(BuildContext context) {
    return FilledButton.icon(
      style: FilledButton.styleFrom(
        backgroundColor: Colors.red,
        foregroundColor: Colors.white,
        minimumSize: const Size.fromHeight(52),
      ),
      onPressed: () {
        HapticFeedback.heavyImpact();
        DriveController.stop();
      },
      icon: const Icon(Icons.stop_circle),
      label: const Text('STOP', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    );
  }
}

// ---------------------------------------------------------------------------
// Pantalla completa horizontal (dos pulgares)
// ---------------------------------------------------------------------------

class DriveFullScreen extends StatefulWidget {
  const DriveFullScreen({super.key});
  @override
  State<DriveFullScreen> createState() => _DriveFullScreenState();
}

class _DriveFullScreenState extends State<DriveFullScreen> {
  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void dispose() {
    DriveController.stop();
    SystemChrome.setPreferredOrientations(const <DeviceOrientation>[]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: SystemUiOverlay.values);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
              child: Row(
                children: [
                  IconButton(
                    tooltip: 'Salir',
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.fullscreen_exit),
                  ),
                  const _StatusIcons(),
                  const Spacer(),
                  ValueListenableBuilder<DriveMode>(
                    valueListenable: DriveController.mode,
                    builder: (_, m, __) => SegmentedButton<DriveMode>(
                      showSelectedIcon: false,
                      style: const ButtonStyle(visualDensity: VisualDensity.compact),
                      segments: const [
                        ButtonSegment(value: DriveMode.arcade, label: Text('Arcade')),
                        ButtonSegment(value: DriveMode.tank, label: Text('Tanque')),
                        ButtonSegment(value: DriveMode.car, label: Text('Auto')),
                      ],
                      selected: {m},
                      onSelectionChanged: (s) => DriveController.setMode(s.first),
                    ),
                  ),
                  const SizedBox(width: 8),
                  SizedBox(
                    width: 120,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.red,
                        foregroundColor: Colors.white,
                      ),
                      onPressed: () {
                        HapticFeedback.heavyImpact();
                        DriveController.stop();
                      },
                      icon: const Icon(Icons.stop_circle),
                      label: const Text('STOP'),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Ajustes',
                    onPressed: () => showDriveSettings(context),
                    icon: const Icon(Icons.tune),
                  ),
                ],
              ),
            ),
            const _Telemetry(),
            const Expanded(
              child: Padding(
                padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: DriveSurface(landscape: true),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Ajustes de conducción y ayuda del gamepad
// ---------------------------------------------------------------------------

Future<void> showDriveSettings(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => const _DriveSettingsSheet(),
  ).whenComplete(DriveController.reloadSettings);
}

class _DriveSettingsSheet extends StatefulWidget {
  const _DriveSettingsSheet();
  @override
  State<_DriveSettingsSheet> createState() => _DriveSettingsSheetState();
}

class _DriveSettingsSheetState extends State<_DriveSettingsSheet> {
  Widget _slider(String title, String valueText, double value, double min, double max,
      int divisions, ValueChanged<double> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text('$title: $valueText'),
        ),
        Slider(
          value: value.clamp(min, max).toDouble(),
          min: min,
          max: max,
          divisions: divisions,
          onChanged: (v) {
            setState(() => onChanged(v));
            DriveController.reloadSettings();
          },
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Gamepad Bluetooth', style: theme.textTheme.titleMedium),
              const SizedBox(height: 4),
              ValueListenableBuilder<List<String>>(
                valueListenable: GamepadManager.devices,
                builder: (_, names, __) => Text(
                  names.isEmpty
                      ? 'No hay gamepad conectado. Ponlo en modo emparejamiento y vincúlalo desde '
                          'los ajustes Bluetooth del celular (como unos audífonos).'
                      : 'Conectado: ${names.join(', ')}',
                  style: theme.textTheme.bodySmall,
                ),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Usar el gamepad'),
                value: AppSettings.padEnabled,
                onChanged: (v) => setState(() => GamepadManager.setEnabled(v)),
              ),
              OutlinedButton.icon(
                onPressed: GamepadManager.openBluetoothSettings,
                icon: const Icon(Icons.bluetooth_searching),
                label: const Text('Emparejar gamepad (ajustes Bluetooth)'),
              ),
              const SizedBox(height: 8),
              Text(
                'Sticks / gatillos: conducir según el modo (Auto: R2 acelera, L2 reversa, stick izq. dirige)\n'
                'A, B, X, Y: caras ^_^  T_T  O_o  >_< en el OLED\n'
                'L1 / R1: bajar / subir velocidad máxima\n'
                'Start: STOP de emergencia · Select: cambiar modo\n'
                'L3 (clic stick izq.): play / pausa música\n'
                'Cruceta ↑ ↓: volumen · ← →: canción anterior / siguiente',
                style: theme.textTheme.bodySmall,
              ),
              const Divider(height: 28),
              Text('Respuesta de los controles', style: theme.textTheme.titleMedium),
              _slider('Sensibilidad (curva)', AppSettings.driveExpo.toStringAsFixed(1),
                  AppSettings.driveExpo, 1.0, 2.5, 15, (v) => AppSettings.driveExpo = v),
              _slider('Zona muerta del joystick táctil',
                  '${(AppSettings.touchDeadzone * 100).round()}%', AppSettings.touchDeadzone,
                  0.0, 0.3, 30, (v) => AppSettings.touchDeadzone = v),
              _slider('Zona muerta del gamepad', '${(AppSettings.padDeadzone * 100).round()}%',
                  AppSettings.padDeadzone, 0.05, 0.4, 35, (v) => AppSettings.padDeadzone = v),
              _slider(
                  'Aceleración suave',
                  AppSettings.driveRampSec <= 0.05
                      ? 'instantánea'
                      : '${AppSettings.driveRampSec.toStringAsFixed(2)} s',
                  AppSettings.driveRampSec,
                  0.0,
                  1.5,
                  30,
                  (v) => AppSettings.driveRampSec = v),
              const Divider(height: 28),
              Text('Servos (calibración)', style: theme.textTheme.titleMedium),
              const SizedBox(height: 4),
              Text(
                'La app sigue enviando SERVO:ángulo1,ángulo2 (90° = detenido). '
                'Si el robot gira al revés o no avanza recto, ajusta aquí.',
                style: theme.textTheme.bodySmall,
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Invertir servo 1'),
                value: AppSettings.invert1,
                onChanged: (v) {
                  setState(() => AppSettings.invert1 = v);
                  DriveController.reloadSettings();
                },
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Invertir servo 2'),
                value: AppSettings.invert2,
                onChanged: (v) {
                  setState(() => AppSettings.invert2 = v);
                  DriveController.reloadSettings();
                },
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Intercambiar servo 1 ↔ 2'),
                subtitle: const Text('Si al girar a la derecha gira a la izquierda.'),
                value: AppSettings.swapMotors,
                onChanged: (v) {
                  setState(() => AppSettings.swapMotors = v);
                  DriveController.reloadSettings();
                },
              ),
              _slider('Arranque mínimo', '${AppSettings.driveMinStart.round()}°',
                  AppSettings.driveMinStart, 0, 30, 30, (v) => AppSettings.driveMinStart = v),
              _slider('Recorrido máximo', '±${AppSettings.driveRange.round()}°',
                  AppSettings.driveRange, 30, 90, 60, (v) => AppSettings.driveRange = v),
              const Divider(height: 28),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Modo zurdo'),
                subtitle: const Text('Intercambia los lados de los controles en pantalla.'),
                value: AppSettings.leftHanded,
                onChanged: (v) => setState(() => AppSettings.leftHanded = v),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Mantener la pantalla encendida'),
                value: AppSettings.keepAwake,
                onChanged: (v) {
                  setState(() => AppSettings.keepAwake = v);
                  SystemBridge.keepScreenOn(v);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
