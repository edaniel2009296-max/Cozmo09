import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../ai_service.dart';
import '../app_settings.dart';
import '../audio_utils.dart';
import '../bluetooth_manager.dart';
import '../music_manager.dart';
import '../speech_output.dart';

enum _Stage { idle, listening, thinking, speaking }

class VoiceScreen extends StatefulWidget {
  const VoiceScreen({super.key});
  @override
  State<VoiceScreen> createState() => _VoiceScreenState();
}

class _VoiceScreenState extends State<VoiceScreen> {
  final stt.SpeechToText _stt = stt.SpeechToText();
  bool _sttReady = false;
  Completer<String>? _sttDone;
  String _sttWords = '';

  bool _stopRequested = false;
  final TextEditingController _input = TextEditingController();

  _Stage _stage = _Stage.idle;
  String _status = 'Listo';
  String _heard = '';
  String _reply = '';
  String _provider = '';
  String _notice = '';
  String _source = AppSettings.micSource;

  bool get _busy => _stage != _Stage.idle;

  @override
  void dispose() {
    _stt.cancel();
    SpeechOutput.stop();
    _input.dispose();
    super.dispose();
  }

  void _setStage(_Stage s, String status) {
    if (!mounted) return;
    setState(() {
      _stage = s;
      _status = status;
    });
  }

  void _fail(String message) {
    if (!mounted) return;
    setState(() {
      _stage = _Stage.idle;
      _status = 'Listo';
      _notice = message;
    });
  }

  // ---------------------------- flujo principal -----------------------------

  Future<void> _onMicPressed() async {
    if (_stage == _Stage.listening) {
      _stopRequested = true;
      if (_source == 'phone') {
        await _stt.stop();
      }
      return;
    }
    if (_busy) return;
    if (mounted) setState(() => _notice = '');
    try {
      if (_source == 'robot') {
        await _robotTurn();
      } else {
        await _phoneTurn();
      }
    } on AIException catch (e) {
      _fail(e.message);
    } catch (e) {
      _fail('Error: $e');
    }
  }

  Future<void> _onTypedSend() async {
    final q = _input.text.trim();
    if (q.isEmpty || _busy) return;
    FocusScope.of(context).unfocus();
    _input.clear();
    if (mounted) setState(() => _notice = '');
    try {
      await _answer(q);
    } on AIException catch (e) {
      _fail(e.message);
    } catch (e) {
      _fail('Error: $e');
    }
  }

  Future<void> _phoneTurn() async {
    final mic = await Permission.microphone.request();
    if (!mic.isGranted) {
      throw AIException(
          'Necesito el permiso del micrófono. Actívalo en los ajustes del celular.');
    }
    _stopRequested = false;
    _setStage(_Stage.listening, 'Escuchando… habla ahora');
    final words = (await _listenPhone()).trim();
    if (words.isEmpty) {
      throw AIException('No te escuché. Toca el micrófono y habla de nuevo.');
    }
    await _answer(words);
  }

  Future<void> _robotTurn() async {
    if (BluetoothManager.rxState.value != BtState.connected) {
      throw AIException(
          'El HC-05 #1 (micrófono del robot) no está conectado. Conéctalo en la pestaña Conexión.');
    }
    _stopRequested = false;
    _setStage(_Stage.listening, 'Escuchando al robot… habla ahora');
    final pcm = await _recordFromRobot();
    _setStage(_Stage.thinking, 'Procesando audio…');
    final wav = AudioUtils.pcm8ToWav(pcm, AppSettings.sampleRate);
    final reply = await AIService.askAudio(wav);
    await _deliver(reply);
  }

  Future<void> _answer(String question) async {
    if (mounted) {
      setState(() {
        _heard = question;
        _reply = '';
      });
    }
    _setStage(_Stage.thinking, 'Pensando…');
    final reply = await AIService.ask(question);
    await _deliver(reply);
  }

  Future<void> _deliver(AIReply r) async {
    if (mounted) {
      setState(() {
        _reply = r.text;
        _provider = r.provider;
        if (r.heard.isNotEmpty) _heard = r.heard;
      });
    }
    _setStage(_Stage.speaking, 'Respondiendo…');
    await MusicManager.pauseForVoice();
    try {
      await _speak(r.text);
    } finally {
      await MusicManager.resumeAfterVoice();
      _setStage(_Stage.idle, 'Listo');
    }
  }

  Future<void> _speak(String text) async {
    final futures = <Future<void>>[];
    final txOn = BluetoothManager.txState.value == BtState.connected;
    var note = '';

    if (txOn) {
      if (AppSettings.txMode == TxMode.text) {
        final ok = await BluetoothManager.write(
          BluetoothManager.slotTx,
          Uint8List.fromList(utf8.encode('$text\n')),
        );
        if (!ok) note = 'No se pudo enviar al HC-05 #2.';
      } else {
        Uint8List? pcm;
        try {
          pcm = await SpeechOutput.synthesizeToPcm8(text, AppSettings.sampleRate);
        } catch (_) {
          pcm = null;
        }
        if (pcm == null) {
          note = 'No pude generar el audio para el robot (revisa el motor de voz del celular).';
        } else {
          futures.add(BluetoothManager.sendPaced(
                  BluetoothManager.slotTx, pcm, AppSettings.sampleRate)
              .then((ok) {
            if (!ok && mounted) {
              setState(() => _notice = 'Se perdió la conexión con el HC-05 #2.');
            }
          }));
        }
      }
    }

    if (AppSettings.speakOnPhone) {
      futures.add(SpeechOutput.speakOnPhone(text));
    } else if (!txOn) {
      note = 'Sin salida de audio: activa «Hablar en el celular» en Ajustes o conecta el HC-05 #2.';
    }

    if (note.isNotEmpty && mounted) setState(() => _notice = note);
    await Future.wait(futures);
  }

  // --------------------------- micrófono del celular ------------------------

  void _finishStt() {
    final c = _sttDone;
    if (c != null && !c.isCompleted) c.complete(_sttWords);
  }

  Future<String> _listenPhone() async {
    if (!_sttReady) {
      _sttReady = await _stt.initialize(
        onStatus: (s) {
          if (s == 'done') {
            Future<void>.delayed(const Duration(milliseconds: 400), _finishStt);
          }
        },
        onError: (e) {
          Future<void>.delayed(const Duration(milliseconds: 100), _finishStt);
        },
      );
    }
    if (!_sttReady) {
      throw AIException(
          'El reconocimiento de voz no está disponible. Instala o activa la app «Google» '
          '(servicios de voz) y da permiso al micrófono.');
    }

    _sttDone = Completer<String>();
    _sttWords = '';

    String? localeId;
    try {
      final sys = await _stt.systemLocale();
      if (sys != null && sys.localeId.toLowerCase().startsWith('es')) {
        localeId = sys.localeId;
      } else {
        final locales = await _stt.locales();
        for (final l in locales) {
          if (l.localeId.toLowerCase().startsWith('es')) {
            localeId = l.localeId;
            break;
          }
        }
      }
    } catch (_) {
      localeId = null;
    }

    await _stt.listen(
      onResult: (r) {
        _sttWords = r.recognizedWords;
        if (r.finalResult) _finishStt();
      },
      localeId: localeId,
      listenFor: const Duration(seconds: 25),
      pauseFor: const Duration(seconds: 3),
      listenOptions: stt.SpeechListenOptions(
        partialResults: true,
        cancelOnError: true,
        listenMode: stt.ListenMode.confirmation,
      ),
    );

    final words = await _sttDone!.future
        .timeout(const Duration(seconds: 35), onTimeout: () => _sttWords);
    if (_stt.isListening) await _stt.stop();
    return words;
  }

  // ---------------------------- micrófono del robot -------------------------

  /// Graba el audio PCM 8 bits que llega por el HC-05 #1 hasta que haya silencio.
  Future<Uint8List> _recordFromRobot() async {
    final sr = AppSettings.sampleRate;
    final buf = BytesBuilder(copy: true);
    final done = Completer<void>();

    var calibAcc = 0.0;
    var calibCount = 0;
    var noise = 0.0;
    var spoke = false;
    final start = DateTime.now();
    var lastVoice = start;

    final sub = BluetoothManager.rxData.listen((chunk) {
      buf.add(chunk);
      final lvl = AudioUtils.level(chunk);
      // Primer medio segundo: medir el ruido de fondo
      if (buf.length < sr ~/ 2) {
        calibAcc += lvl;
        calibCount++;
        noise = calibAcc / calibCount;
        return;
      }
      final threshold = math.max(noise * 2.5, noise + 4);
      if (lvl > threshold) {
        spoke = true;
        lastVoice = DateTime.now();
      }
    });

    final tick = Timer.periodic(const Duration(milliseconds: 100), (_) {
      final now = DateTime.now();
      final elapsed = now.difference(start);
      final stop = _stopRequested ||
          elapsed > const Duration(seconds: 12) ||
          (spoke && now.difference(lastVoice) > const Duration(milliseconds: 1200)) ||
          (!spoke && elapsed > const Duration(seconds: 7)) ||
          (buf.length == 0 && elapsed > const Duration(seconds: 3));
      if (stop && !done.isCompleted) done.complete();
    });

    await done.future;
    tick.cancel();
    await sub.cancel();

    final bytes = buf.takeBytes();
    if (bytes.isEmpty) {
      throw AIException(
          'No llega audio del robot por el HC-05 #1. Revisa que esté conectado, que el robot '
          'esté enviando audio y que la velocidad (baudios) y la frecuencia coincidan con los Ajustes.');
    }
    if (!spoke) {
      throw AIException('No detecté voz en el micrófono del robot. Habla más cerca e inténtalo de nuevo.');
    }
    return Uint8List.fromList(bytes);
  }

  // ----------------------------------- UI -----------------------------------

  @override
  Widget build(BuildContext context) {
    final listening = _stage == _Stage.listening;
    final theme = Theme.of(context);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(
                value: 'phone',
                label: Text('Mic celular'),
                icon: Icon(Icons.phone_android),
              ),
              ButtonSegment(
                value: 'robot',
                label: Text('Mic robot'),
                icon: Icon(Icons.smart_toy),
              ),
            ],
            selected: {_source},
            onSelectionChanged: _busy
                ? null
                : (s) {
                    setState(() => _source = s.first);
                    AppSettings.micSource = s.first;
                  },
          ),
          const SizedBox(height: 24),
          Center(child: Text(_status, style: theme.textTheme.titleMedium)),
          const SizedBox(height: 16),
          Center(
            child: SizedBox(
              width: 120,
              height: 120,
              child: FilledButton(
                onPressed: (_busy && !listening) ? null : _onMicPressed,
                style: FilledButton.styleFrom(
                  shape: const CircleBorder(),
                  padding: EdgeInsets.zero,
                  backgroundColor: listening ? Colors.red : null,
                ),
                child: Icon(listening ? Icons.stop : Icons.mic, size: 56),
              ),
            ),
          ),
          if (_stage == _Stage.thinking || _stage == _Stage.speaking) ...[
            const SizedBox(height: 16),
            const LinearProgressIndicator(),
          ],
          const SizedBox(height: 20),
          if (_heard.isNotEmpty)
            Card(
              child: ListTile(
                leading: const Icon(Icons.hearing),
                title: const Text('Te escuché'),
                subtitle: Text(_heard),
              ),
            ),
          if (_reply.isNotEmpty)
            Card(
              child: ListTile(
                leading: const Icon(Icons.smart_toy),
                title: const Text('Cozmo'),
                subtitle: Text(_reply),
                trailing: null,
              ),
            ),
          if (_provider.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 4),
              child: Text('IA: $_provider', style: theme.textTheme.bodySmall),
            ),
          if (_notice.isNotEmpty)
            Card(
              color: theme.colorScheme.errorContainer,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(
                  _notice,
                  style: TextStyle(color: theme.colorScheme.onErrorContainer),
                ),
              ),
            ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _input,
                  enabled: !_busy,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _onTypedSend(),
                  decoration: const InputDecoration(
                    labelText: 'O escribe tu pregunta',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                onPressed: _busy ? null : _onTypedSend,
                icon: const Icon(Icons.send),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: () {
                AIService.clearHistory();
                setState(() {
                  _heard = '';
                  _reply = '';
                  _provider = '';
                  _notice = '';
                });
              },
              icon: const Icon(Icons.delete_outline),
              label: const Text('Borrar conversación'),
            ),
          ),
        ],
      ),
    );
  }
}
