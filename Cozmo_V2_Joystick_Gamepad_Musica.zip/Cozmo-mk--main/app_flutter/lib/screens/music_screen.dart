import 'dart:async';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../app_settings.dart';
import '../bluetooth_manager.dart';
import '../music_manager.dart';
import '../system_bridge.dart';

/// Pestaña "Música", separada del resto del robot.
///  - Parlante BT: el audio sale por el sistema Android hacia el parlante Bluetooth (A2DP),
///    por ejemplo la placa Bluetooth de un parlante viejo. No usa HC-05.
///  - HC-05 #2: el audio se manda por el HC-05 al Arduino y al amplificador del robot.
class MusicScreen extends StatefulWidget {
  const MusicScreen({super.key});
  @override
  State<MusicScreen> createState() => _MusicScreenState();
}

class _MusicScreenState extends State<MusicScreen> {
  Timer? _routeTimer;
  bool _a2dp = false;
  String _a2dpName = '';
  bool _seeking = false;
  double _seekValue = 0;

  @override
  void initState() {
    super.initState();
    _refreshRoute();
    _routeTimer = Timer.periodic(const Duration(seconds: 3), (_) => _refreshRoute());
  }

  @override
  void dispose() {
    _routeTimer?.cancel();
    super.dispose();
  }

  Future<void> _refreshRoute() async {
    final r = await SystemBridge.audioRoute();
    if (!mounted) return;
    if (r.a2dp != _a2dp || r.name != _a2dpName) {
      setState(() {
        _a2dp = r.a2dp;
        _a2dpName = r.name;
      });
    }
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  String _titleOf(String name) {
    final i = name.lastIndexOf('.');
    return i > 0 ? name.substring(0, i) : name;
  }

  Future<void> _addSongs() async {
    try {
      final res = await FilePicker.platform.pickFiles(type: FileType.audio, allowMultiple: true);
      if (res == null) return;
      final tracks = <Track>[];
      for (final f in res.files) {
        final p = f.path;
        if (p == null) continue;
        tracks.add(Track(p, _titleOf(f.name)));
      }
      if (tracks.isEmpty) {
        _snack('No se pudo leer ningún archivo.');
        return;
      }
      MusicManager.addTracks(tracks);
      _snack('${tracks.length} canción(es) agregada(s)');
    } catch (e) {
      _snack('No se pudo abrir el selector de archivos: $e');
    }
  }

  String _fmt(int ms) {
    final s = ms ~/ 1000;
    final m = s ~/ 60;
    final r = s % 60;
    return '$m:${r.toString().padLeft(2, '0')}';
  }

  // ------------------------------- UI -------------------------------

  Widget _outputCard(BuildContext context) {
    final theme = Theme.of(context);
    return ValueListenableBuilder<MusicOutput>(
      valueListenable: MusicManager.output,
      builder: (_, out, __) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Salida de audio', style: theme.textTheme.titleMedium),
              const SizedBox(height: 10),
              SegmentedButton<MusicOutput>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(
                    value: MusicOutput.phone,
                    icon: Icon(Icons.bluetooth_audio),
                    label: Text('Parlante BT'),
                  ),
                  ButtonSegment(
                    value: MusicOutput.hc05,
                    icon: Icon(Icons.settings_input_antenna),
                    label: Text('HC-05 #2'),
                  ),
                ],
                selected: {out},
                onSelectionChanged: (s) => MusicManager.setOutput(s.first),
              ),
              const SizedBox(height: 12),
              if (out == MusicOutput.phone) ...[
                Row(
                  children: [
                    Icon(
                      _a2dp ? Icons.bluetooth_connected : Icons.phone_android,
                      color: _a2dp ? Colors.green : Colors.orange,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _a2dp
                            ? 'Sonando por el parlante Bluetooth: $_a2dpName'
                            : 'No hay parlante Bluetooth conectado: por ahora suena en el celular.',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  'Para la placa Bluetooth de un parlante viejo: enciéndela, empárejala una vez '
                  'en los ajustes Bluetooth del celular y listo. El audio va directo del celular '
                  'a la placa y al parlante, con calidad normal de música (no usa el HC-05).',
                  style: theme.textTheme.bodySmall,
                ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: SystemBridge.openBluetoothSettings,
                  icon: const Icon(Icons.settings_bluetooth),
                  label: const Text('Abrir ajustes Bluetooth'),
                ),
              ] else ...[
                ValueListenableBuilder<BtState>(
                  valueListenable: BluetoothManager.txState,
                  builder: (_, st, __) => Row(
                    children: [
                      Icon(
                        Icons.circle,
                        size: 12,
                        color: st == BtState.connected ? Colors.green : Colors.red,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(st == BtState.connected
                            ? 'HC-05 #2 conectado'
                            : 'HC-05 #2 desconectado (conéctalo en la pestaña Conexión)'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Manda la música por el HC-05 #2 en el mismo formato que la voz del robot '
                  '(mono, 8 bits, ${AppSettings.sampleRate} Hz, la frecuencia de Ajustes), hacia el '
                  'Arduino y el amplificador. La calidad es tipo radio AM porque el formato es el '
                  'de la voz. Si el robot habla, la música se pausa sola y continúa después.',
                  style: theme.textTheme.bodySmall,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _playerCard(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: ListenableBuilder(
          listenable: Listenable.merge(<Listenable>[
            MusicManager.playlist,
            MusicManager.currentIndex,
            MusicManager.playing,
            MusicManager.positionMs,
            MusicManager.durationMs,
            MusicManager.shuffle,
            MusicManager.repeat,
            MusicManager.volume,
            MusicManager.error,
          ]),
          builder: (context, _) {
            final list = MusicManager.playlist.value;
            final idx = MusicManager.currentIndex.value;
            final title = (idx >= 0 && idx < list.length) ? list[idx].title : 'Ninguna canción';
            final dur = MusicManager.durationMs.value;
            final pos = _seeking ? _seekValue : MusicManager.positionMs.value.toDouble();
            final playing = MusicManager.playing.value;
            final rep = MusicManager.repeat.value;
            final err = MusicManager.error.value;

            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    const Icon(Icons.music_note),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        title,
                        style: theme.textTheme.titleMedium,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
                Slider(
                  value: dur > 0 ? pos.clamp(0.0, dur.toDouble()).toDouble() : 0.0,
                  min: 0,
                  max: dur > 0 ? dur.toDouble() : 1.0,
                  onChangeStart: (v) {
                    _seeking = true;
                    _seekValue = v;
                  },
                  onChanged: (v) => setState(() => _seekValue = v),
                  onChangeEnd: (v) {
                    _seeking = false;
                    MusicManager.seekTo(v.round());
                  },
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(_fmt(pos.round()), style: theme.textTheme.bodySmall),
                    Text(_fmt(dur), style: theme.textTheme.bodySmall),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      tooltip: 'Aleatorio',
                      onPressed: MusicManager.toggleShuffle,
                      icon: Icon(
                        Icons.shuffle,
                        color: MusicManager.shuffle.value ? theme.colorScheme.primary : null,
                      ),
                    ),
                    IconButton(
                      iconSize: 36,
                      onPressed: MusicManager.prev,
                      icon: const Icon(Icons.skip_previous),
                    ),
                    IconButton.filled(
                      iconSize: 40,
                      onPressed: MusicManager.togglePlay,
                      icon: Icon(playing ? Icons.pause : Icons.play_arrow),
                    ),
                    IconButton(
                      iconSize: 36,
                      onPressed: MusicManager.next,
                      icon: const Icon(Icons.skip_next),
                    ),
                    IconButton(
                      tooltip: 'Repetir',
                      onPressed: MusicManager.cycleRepeat,
                      icon: Icon(
                        rep == RepeatMode.one ? Icons.repeat_one : Icons.repeat,
                        color: rep == RepeatMode.off ? null : theme.colorScheme.primary,
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    const Icon(Icons.volume_down),
                    Expanded(
                      child: Slider(
                        value: MusicManager.volume.value,
                        min: 0,
                        max: 1,
                        onChanged: MusicManager.setVolume,
                      ),
                    ),
                    const Icon(Icons.volume_up),
                  ],
                ),
                if (err.isNotEmpty)
                  Container(
                    margin: const EdgeInsets.only(top: 4),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.errorContainer,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      err,
                      style: TextStyle(color: theme.colorScheme.onErrorContainer),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _listCard(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: ListenableBuilder(
          listenable: Listenable.merge(<Listenable>[
            MusicManager.playlist,
            MusicManager.currentIndex,
            MusicManager.playing,
          ]),
          builder: (context, _) {
            final list = MusicManager.playlist.value;
            final cur = MusicManager.currentIndex.value;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text('Lista (${list.length})', style: theme.textTheme.titleMedium),
                      ),
                      TextButton.icon(
                        onPressed: _addSongs,
                        icon: const Icon(Icons.library_add),
                        label: const Text('Agregar'),
                      ),
                      if (list.isNotEmpty)
                        IconButton(
                          tooltip: 'Vaciar lista',
                          onPressed: MusicManager.clear,
                          icon: const Icon(Icons.delete_sweep),
                        ),
                    ],
                  ),
                ),
                if (list.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(16),
                    child: Text('Toca «Agregar» y elige canciones de tu celular (mp3, m4a, wav, ogg, flac).'),
                  ),
                for (var i = 0; i < list.length; i++)
                  ListTile(
                    dense: true,
                    selected: i == cur,
                    leading: i == cur
                        ? Icon(MusicManager.playing.value ? Icons.equalizer : Icons.pause)
                        : Text('${i + 1}'),
                    title: Text(list[i].title, maxLines: 1, overflow: TextOverflow.ellipsis),
                    trailing: IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => MusicManager.removeAt(i),
                    ),
                    onTap: () => MusicManager.playIndex(i),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _outputCard(context),
        _playerCard(context),
        _listCard(context),
        const SizedBox(height: 8),
        Text(
          'Con el gamepad: L3 play/pausa · cruceta ←/→ cambia de canción · ↑/↓ volumen.',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }
}
