import 'package:flutter/material.dart';

import '../websocket_manager.dart';

class ServoScreen extends StatefulWidget {
  const ServoScreen({super.key});
  @override
  State<ServoScreen> createState() => _ServoScreenState();
}

class _ServoScreenState extends State<ServoScreen> {
  int servo1 = 90;
  int servo2 = 90;

  void _send() {
    final ok = WebSocketManager.sendCommand('SERVO:$servo1,$servo2');
    if (!ok) {
      ScaffoldMessenger.of(context)
        ..clearSnackBars()
        ..showSnackBar(const SnackBar(
          content: Text('NodeMCU no conectado. Conéctalo en la pestaña Conexión.'),
        ));
    }
  }

  void _moveServo(int s1, int s2) {
    setState(() {
      servo1 = (servo1 + s1).clamp(0, 180).toInt();
      servo2 = (servo2 + s2).clamp(0, 180).toInt();
    });
    _send();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Text('Servo 1: $servo1° | Servo 2: $servo2°',
              style: const TextStyle(fontSize: 18)),
          const SizedBox(height: 12),
          // D-Pad
          IconButton(
            icon: const Icon(Icons.arrow_upward),
            onPressed: () => _moveServo(10, 10),
            iconSize: 50,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => _moveServo(-10, 10),
                iconSize: 50,
              ),
              const SizedBox(width: 20),
              IconButton(
                icon: const Icon(Icons.arrow_forward),
                onPressed: () => _moveServo(10, -10),
                iconSize: 50,
              ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.arrow_downward),
            onPressed: () => _moveServo(-10, -10),
            iconSize: 50,
          ),
          const SizedBox(height: 12),
          const Align(alignment: Alignment.centerLeft, child: Text('Servo 1')),
          Slider(
            value: servo1.toDouble(),
            min: 0,
            max: 180,
            divisions: 180,
            label: '$servo1°',
            onChanged: (v) => setState(() => servo1 = v.round()),
            onChangeEnd: (_) => _send(),
          ),
          const Align(alignment: Alignment.centerLeft, child: Text('Servo 2')),
          Slider(
            value: servo2.toDouble(),
            min: 0,
            max: 180,
            divisions: 180,
            label: '$servo2°',
            onChanged: (v) => setState(() => servo2 = v.round()),
            onChangeEnd: (_) => _send(),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: () => _moveServo(90 - servo1, 90 - servo2), // centrar a 90°
            child: const Text('Centrar servos'),
          ),
        ],
      ),
    );
  }
}
