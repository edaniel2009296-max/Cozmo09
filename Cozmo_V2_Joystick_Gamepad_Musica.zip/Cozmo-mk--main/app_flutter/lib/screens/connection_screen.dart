import 'dart:async';

import 'package:flutter/material.dart';

import '../app_settings.dart';
import '../bluetooth_manager.dart';
import '../websocket_manager.dart';

class ConnectionScreen extends StatefulWidget {
  const ConnectionScreen({super.key});
  @override
  State<ConnectionScreen> createState() => _ConnectionScreenState();
}

class _ConnectionScreenState extends State<ConnectionScreen> {
  final TextEditingController _ip = TextEditingController(text: AppSettings.nodeIp);
  final TextEditingController _port =
      TextEditingController(text: AppSettings.nodePort.toString());

  final Map<String, BtDevice> _devices = {};
  String? _rxAddr = AppSettings.rxAddress.isEmpty ? null : AppSettings.rxAddress;
  String? _txAddr = AppSettings.txAddress.isEmpty ? null : AppSettings.txAddress;
  StreamSubscription<BtDevice>? _foundSub;

  @override
  void initState() {
    super.initState();
    if (_rxAddr != null) {
      _devices[_rxAddr!] = BtDevice(AppSettings.rxName, _rxAddr!);
    }
    if (_txAddr != null) {
      _devices[_txAddr!] = BtDevice(AppSettings.txName, _txAddr!);
    }
    _foundSub = BluetoothManager.found.listen((d) {
      if (!mounted || d.address.isEmpty) return;
      final old = _devices[d.address];
      if (old == null || (d.name.isNotEmpty && old.name != d.name)) {
        setState(() => _devices[d.address] = d);
      }
    });
    _loadBonded(silent: true);
  }

  @override
  void dispose() {
    _foundSub?.cancel();
    _ip.dispose();
    _port.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _loadBonded({bool silent = false}) async {
    try {
      await BluetoothManager.ensurePermissions();
      final list = await BluetoothManager.bonded();
      if (!mounted) return;
      setState(() {
        for (final d in list) {
          _devices[d.address] = d;
        }
      });
    } catch (e) {
      if (!silent) _snack('No se pudo leer Bluetooth: $e');
    }
  }

  Future<void> _scan() async {
    await BluetoothManager.ensurePermissions();
    if (!await BluetoothManager.isEnabled()) {
      await BluetoothManager.requestEnable();
      _snack('Enciende el Bluetooth y vuelve a tocar «Buscar».');
      return;
    }
    await _loadBonded(silent: true);
    final ok = await BluetoothManager.startDiscovery();
    if (!ok) {
      _snack('No se pudo iniciar la búsqueda. Revisa los permisos de Bluetooth.');
    } else {
      _snack('Buscando dispositivos… (unos 12 segundos)');
    }
  }

  // ------------------------------- NodeMCU ---------------------------------

  Future<void> _toggleWs() async {
    if (WebSocketManager.state.value == WsState.connected) {
      await WebSocketManager.disconnect();
      return;
    }
    final port = int.tryParse(_port.text.trim()) ?? 81;
    AppSettings.nodeIp = _ip.text.trim();
    AppSettings.nodePort = port;
    final err = await WebSocketManager.connect(_ip.text, port: port);
    _snack(err ?? 'NodeMCU conectado');
  }

  // -------------------------------- HC-05 ----------------------------------

  Future<bool> _connectBt(String slot) async {
    final addr = slot == BluetoothManager.slotRx ? _rxAddr : _txAddr;
    final label = slot == BluetoothManager.slotRx ? 'HC-05 #1' : 'HC-05 #2';
    if (addr == null) {
      _snack('Elige primero el dispositivo para el $label.');
      return false;
    }
    if (_rxAddr != null && _rxAddr == _txAddr) {
      _snack('Elige dos HC-05 distintos: uno para el #1 y otro para el #2.');
      return false;
    }
    await BluetoothManager.ensurePermissions();
    if (!await BluetoothManager.isEnabled()) {
      await BluetoothManager.requestEnable();
      _snack('Enciende el Bluetooth y vuelve a intentar.');
      return false;
    }
    await BluetoothManager.stopDiscovery();
    final err = await BluetoothManager.connect(slot, addr);
    _snack(err ?? '$label conectado');
    return err == null;
  }

  Future<void> _toggleBt(String slot) async {
    if (BluetoothManager.state(slot).value == BtState.connected) {
      await BluetoothManager.disconnect(slot);
      return;
    }
    await _connectBt(slot);
  }

  Future<void> _connectAll() async {
    if (_ip.text.trim().isNotEmpty && !WebSocketManager.isConnected) {
      await _toggleWs();
    }
    if (_rxAddr != null && BluetoothManager.rxState.value != BtState.connected) {
      await _connectBt(BluetoothManager.slotRx);
    }
    if (_txAddr != null && BluetoothManager.txState.value != BtState.connected) {
      await _connectBt(BluetoothManager.slotTx);
    }
  }

  void _pick(String slot, String? address) {
    if (address == null) return;
    final name = _devices[address]?.name ?? '';
    setState(() {
      if (slot == BluetoothManager.slotRx) {
        _rxAddr = address;
        AppSettings.rxAddress = address;
        AppSettings.rxName = name;
      } else {
        _txAddr = address;
        AppSettings.txAddress = address;
        AppSettings.txName = name;
      }
    });
  }

  // --------------------------------- UI ------------------------------------

  Widget _statusRow(String text, bool ok, bool busy, VoidCallback? onPressed, String button) {
    return Row(
      children: [
        Icon(Icons.circle, size: 12, color: ok ? Colors.green : (busy ? Colors.orange : Colors.red)),
        const SizedBox(width: 8),
        Expanded(child: Text(text)),
        FilledButton(onPressed: busy ? null : onPressed, child: Text(button)),
      ],
    );
  }

  Widget _btCard({
    required String slot,
    required String title,
    required String subtitle,
    required String? addr,
  }) {
    final items = _devices.values.toList()..sort((a, b) => a.label.compareTo(b.label));
    final value = (addr != null && _devices.containsKey(addr)) ? addr : null;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 2),
            Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: value,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Dispositivo',
                border: OutlineInputBorder(),
              ),
              items: [
                for (final d in items)
                  DropdownMenuItem<String>(
                    value: d.address,
                    child: Text(d.label, overflow: TextOverflow.ellipsis),
                  ),
              ],
              onChanged: (v) => _pick(slot, v),
            ),
            const SizedBox(height: 12),
            ValueListenableBuilder<BtState>(
              valueListenable: BluetoothManager.state(slot),
              builder: (_, st, __) => _statusRow(
                st == BtState.connected
                    ? 'Conectado'
                    : (st == BtState.connecting ? 'Conectando…' : 'Desconectado'),
                st == BtState.connected,
                st == BtState.connecting,
                () => _toggleBt(slot),
                st == BtState.connected ? 'Desconectar' : 'Conectar',
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('NodeMCU (WiFi)', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 2),
                  Text(
                    'OLED y servos. El celular debe estar en el mismo WiFi que el NodeMCU.',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: TextField(
                          controller: _ip,
                          keyboardType: TextInputType.url,
                          decoration: const InputDecoration(
                            labelText: 'IP del NodeMCU',
                            hintText: '192.168.1.50',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        flex: 1,
                        child: TextField(
                          controller: _port,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'Puerto',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ValueListenableBuilder<WsState>(
                    valueListenable: WebSocketManager.state,
                    builder: (_, st, __) => _statusRow(
                      st == WsState.connected
                          ? 'Conectado'
                          : (st == WsState.connecting ? 'Conectando…' : 'Desconectado'),
                      st == WsState.connected,
                      st == WsState.connecting,
                      _toggleWs,
                      st == WsState.connected ? 'Desconectar' : 'Conectar',
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: ValueListenableBuilder<bool>(
                  valueListenable: BluetoothManager.scanning,
                  builder: (_, scanning, __) => OutlinedButton.icon(
                    onPressed: scanning ? null : _scan,
                    icon: scanning
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.bluetooth_searching),
                    label: Text(scanning ? 'Buscando…' : 'Buscar HC-05'),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(
                  onPressed: _connectAll,
                  icon: const Icon(Icons.link),
                  label: const Text('Conectar todo'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _btCard(
            slot: BluetoothManager.slotRx,
            title: 'HC-05 #1 · Micrófono del robot',
            subtitle: 'Recibe el audio del robot hacia la app.',
            addr: _rxAddr,
          ),
          _btCard(
            slot: BluetoothManager.slotTx,
            title: 'HC-05 #2 · Altavoz del robot',
            subtitle: 'Envía la voz de la IA de la app hacia el robot.',
            addr: _txAddr,
          ),
          const SizedBox(height: 4),
          Text(
            'Si el HC-05 no aparece, tócalo en «Buscar HC-05». Al conectar por primera vez '
            'Android pedirá la clave: normalmente 1234 o 0000.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}
