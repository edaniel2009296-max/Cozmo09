import 'package:flutter/material.dart';

import '../websocket_manager.dart';

class OledScreen extends StatefulWidget {
  const OledScreen({super.key});
  @override
  State<OledScreen> createState() => _OledScreenState();
}

class _OledScreenState extends State<OledScreen> {
  String selectedFace = '0-0';
  final TextEditingController _textController = TextEditingController();

  final List<String> faces = const ['0-0', '0_0', '^_^', '-_-', 'T_T', 'O_o', '>_<'];

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  void _sendToOLED() {
    final text = _textController.text.replaceAll('|', ' ').trim();
    final ok = WebSocketManager.sendCommand('FACE:$selectedFace|TEXT:$text');
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(ok
            ? 'Enviado al OLED'
            : 'NodeMCU no conectado. Conéctalo en la pestaña Conexión.'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ValueListenableBuilder<WsState>(
            valueListenable: WebSocketManager.state,
            builder: (_, st, __) => Text(
              st == WsState.connected ? 'NodeMCU conectado' : 'NodeMCU desconectado',
              style: Theme.of(context).textTheme.labelLarge,
            ),
          ),
          const SizedBox(height: 16),
          const Text('Selecciona una cara:', style: TextStyle(fontSize: 18)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 10,
            runSpacing: 8,
            children: faces.map((face) {
              return ChoiceChip(
                label: Text(face),
                selected: selectedFace == face,
                onSelected: (_) => setState(() => selectedFace = face),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          TextField(
            controller: _textController,
            decoration: const InputDecoration(
              labelText: 'Texto para mostrar (opcional)',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 20),
          Center(
            child: FilledButton.icon(
              onPressed: _sendToOLED,
              icon: const Icon(Icons.send),
              label: const Text('Enviar a pantalla OLED'),
            ),
          ),
        ],
      ),
    );
  }
}
