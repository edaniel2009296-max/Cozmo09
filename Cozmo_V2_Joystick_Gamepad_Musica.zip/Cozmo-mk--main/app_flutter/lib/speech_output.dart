import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_tts/flutter_tts.dart';
import 'package:path_provider/path_provider.dart';

import 'audio_utils.dart';

/// Texto a voz: reproduce en el celular y/o genera audio PCM para el robot.
class SpeechOutput {
  static final FlutterTts _tts = FlutterTts();
  static bool _ready = false;

  static Future<void> _init() async {
    if (_ready) return;
    try {
      await _tts.setLanguage('es-ES');
    } catch (_) {}
    try {
      await _tts.setSpeechRate(0.5);
      await _tts.awaitSpeakCompletion(true);
    } catch (_) {}
    _ready = true;
  }

  static Future<void> speakOnPhone(String text) async {
    await _init();
    await _tts.speak(text);
  }

  static Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }

  /// Sintetiza [text] a un WAV con el motor de voz del celular y lo convierte a
  /// PCM 8 bits sin signo mono a [rate] Hz (el formato que espera el robot).
  static Future<Uint8List?> synthesizeToPcm8(String text, int rate) async {
    await _init();
    final dir = await getExternalStorageDirectory();
    if (dir == null) return null;

    const name = 'cozmo_tts.wav';
    final file = File('${dir.path}/$name');
    if (await file.exists()) {
      await file.delete();
    }

    await _tts.synthesizeToFile(text, name);

    // Esperar a que el motor termine de escribir (tamaño estable)
    var last = -1;
    var stable = 0;
    for (var i = 0; i < 100; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 200));
      if (await file.exists()) {
        final len = await file.length();
        if (len > 44 && len == last) {
          stable++;
          if (stable >= 2) break;
        } else {
          stable = 0;
        }
        last = len;
      }
    }
    if (!await file.exists()) return null;

    final bytes = await file.readAsBytes();
    return AudioUtils.wavToPcm8(bytes, rate);
  }
}
