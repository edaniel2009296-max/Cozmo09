import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

class BtDevice {
  final String name;
  final String address;
  const BtDevice(this.name, this.address);

  String get label => name.isEmpty ? address : '$name ($address)';
}

enum BtState { disconnected, connecting, connected }

/// Bluetooth clásico (SPP) con los dos HC-05, usando el código nativo de MainActivity.kt.
///  - slot "rx": HC-05 #1, audio del micrófono del robot -> app
///  - slot "tx": HC-05 #2, audio de la app -> altavoz del robot
class BluetoothManager {
  static const String slotRx = 'rx';
  static const String slotTx = 'tx';

  static const MethodChannel _method = MethodChannel('cozmo/bt');
  static const EventChannel _events = EventChannel('cozmo/bt_events');

  static final ValueNotifier<BtState> rxState = ValueNotifier(BtState.disconnected);
  static final ValueNotifier<BtState> txState = ValueNotifier(BtState.disconnected);
  static final ValueNotifier<bool> scanning = ValueNotifier(false);

  static final StreamController<Uint8List> _rxData = StreamController<Uint8List>.broadcast();
  static final StreamController<BtDevice> _found = StreamController<BtDevice>.broadcast();

  /// Bytes que llegan del HC-05 #1 (audio del robot).
  static Stream<Uint8List> get rxData => _rxData.stream;

  /// Dispositivos encontrados durante la búsqueda.
  static Stream<BtDevice> get found => _found.stream;

  static bool _started = false;

  static ValueNotifier<BtState> state(String slot) =>
      slot == slotRx ? rxState : txState;

  static void init() {
    if (_started) return;
    _started = true;
    _events.receiveBroadcastStream().listen(_onEvent, onError: (Object e) {
      debugPrint('BT events error: $e');
    });
  }

  static void _onEvent(dynamic event) {
    if (event is! Map) return;
    final type = event['type'];
    switch (type) {
      case 'data':
        final data = event['data'];
        if (data is Uint8List && event['slot'] == slotRx) {
          _rxData.add(data);
        }
        break;
      case 'closed':
        final slot = event['slot'];
        if (slot is String) state(slot).value = BtState.disconnected;
        break;
      case 'found':
        _found.add(BtDevice(
          (event['name'] ?? '').toString(),
          (event['address'] ?? '').toString(),
        ));
        break;
      case 'scanDone':
        scanning.value = false;
        break;
    }
  }

  /// Pide los permisos de Bluetooth (y ubicación solo en Android 11 o menor).
  static Future<void> ensurePermissions() async {
    final res = await [Permission.bluetoothScan, Permission.bluetoothConnect].request();
    final scanOk = res[Permission.bluetoothScan]?.isGranted ?? false;
    if (!scanOk) {
      // Android 11 o menor: el escaneo exige ubicación
      await Permission.locationWhenInUse.request();
    }
  }

  static Future<bool> isEnabled() async {
    try {
      return await _method.invokeMethod<bool>('isEnabled') ?? false;
    } on PlatformException {
      return false;
    }
  }

  static Future<void> requestEnable() async {
    try {
      await _method.invokeMethod<bool>('requestEnable');
    } on PlatformException {
      // ignorar
    }
  }

  /// Dispositivos ya emparejados con el celular.
  static Future<List<BtDevice>> bonded() async {
    final list = await _method.invokeMethod<List<dynamic>>('bonded') ?? [];
    return list.map((e) {
      final m = e as Map;
      return BtDevice((m['name'] ?? '').toString(), (m['address'] ?? '').toString());
    }).toList();
  }

  static Future<bool> startDiscovery() async {
    try {
      final ok = await _method.invokeMethod<bool>('startDiscovery') ?? false;
      scanning.value = ok;
      return ok;
    } on PlatformException {
      scanning.value = false;
      return false;
    }
  }

  static Future<void> stopDiscovery() async {
    try {
      await _method.invokeMethod<bool>('stopDiscovery');
    } on PlatformException {
      // ignorar
    }
    scanning.value = false;
  }

  /// Devuelve null si conectó bien, o el mensaje de error.
  static Future<String?> connect(String slot, String address) async {
    final st = state(slot);
    st.value = BtState.connecting;
    try {
      await _method.invokeMethod<bool>('connect', {'slot': slot, 'address': address});
      st.value = BtState.connected;
      return null;
    } on PlatformException catch (e) {
      st.value = BtState.disconnected;
      return e.message ?? 'No se pudo conectar';
    } catch (e) {
      st.value = BtState.disconnected;
      return 'No se pudo conectar: $e';
    }
  }

  static Future<void> disconnect(String slot) async {
    try {
      await _method.invokeMethod<bool>('disconnect', {'slot': slot});
    } on PlatformException {
      // ignorar
    }
    state(slot).value = BtState.disconnected;
  }

  /// Escribe bytes al HC-05. Devuelve false si falla o no hay conexión.
  static Future<bool> write(String slot, Uint8List data) async {
    if (state(slot).value != BtState.connected) return false;
    try {
      await _method.invokeMethod<bool>('write', {'slot': slot, 'data': data});
      return true;
    } on PlatformException {
      state(slot).value = BtState.disconnected;
      return false;
    }
  }

  /// Envía audio al ritmo de reproducción (bytesPerSecond) para no desbordar
  /// el buffer del HC-05 ni del Arduino.
  static Future<bool> sendPaced(String slot, Uint8List data, int bytesPerSecond) async {
    const chunk = 256;
    final sw = Stopwatch()..start();
    for (var off = 0; off < data.length; off += chunk) {
      final end = math.min(off + chunk, data.length);
      final ok = await write(slot, Uint8List.sublistView(data, off, end));
      if (!ok) return false;
      final targetMs = end * 1000 ~/ bytesPerSecond;
      final waitMs = targetMs - sw.elapsedMilliseconds - 300; // 300 ms de adelanto
      if (waitMs > 0) {
        await Future<void>.delayed(Duration(milliseconds: waitMs));
      }
    }
    return true;
  }
}
