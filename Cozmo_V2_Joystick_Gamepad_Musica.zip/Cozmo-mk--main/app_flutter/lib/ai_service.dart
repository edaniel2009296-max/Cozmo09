import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import 'app_settings.dart';

/// Error con un mensaje listo para mostrar al usuario.
class AIException implements Exception {
  final String message;
  AIException(this.message);
  @override
  String toString() => message;
}

class AIReply {
  /// Lo que entendió la IA del audio (solo cuando se usa el micrófono del robot).
  final String heard;
  final String text;

  /// Qué servicio respondió (para mostrarlo en pantalla).
  final String provider;
  const AIReply({required this.heard, required this.text, required this.provider});
}

class _Turn {
  final String role; // 'user' | 'model'
  final String text;
  const _Turn(this.role, this.text);
}

/// IA 100% gratuita:
///  1) Gemini (Google AI Studio, plan gratis, sin tarjeta). Necesita una API key gratuita.
///     El modelo se descubre automáticamente para que no se rompa cuando Google retira modelos.
///  2) Pollinations (sin clave ni registro) como respaldo si no hay key o Gemini falla.
class AIService {
  static const String _system =
      'Eres Cozmo, un pequeño robot amigable, curioso y simpático. '
      'Responde siempre en español, de forma natural y breve (máximo 2 o 3 oraciones). '
      'No uses emojis, markdown, listas ni símbolos raros: tu respuesta se leerá en voz alta.';

  static const String _audioPrompt =
      'Escucha el audio: es una persona hablándole a un robot. '
      'Responde SOLO con un JSON con este formato exacto: '
      '{"pregunta": "<transcripción literal de lo que dijo>", "respuesta": "<tu respuesta breve para el robot>"}. '
      'Si no hay voz clara, deja "pregunta" vacía y en "respuesta" pide amablemente que repita.';

  static const String _gemBase = 'https://generativelanguage.googleapis.com/v1beta';

  /// Modelos de respaldo por si no se puede consultar la lista (de más a menos probable).
  static const List<String> _fallbackModels = [
    'gemini-3.1-flash-lite',
    'gemini-flash-lite-latest',
    'gemini-3-flash-preview',
    'gemini-flash-latest',
    'gemini-2.5-flash-lite',
    'gemini-2.5-flash',
  ];

  static final List<_Turn> _history = [];
  static List<String>? _discovered;

  static void clearHistory() => _history.clear();

  // ---------------------------------------------------------------------------
  // API pública
  // ---------------------------------------------------------------------------

  /// Pregunta en texto.
  static Future<AIReply> ask(String text) async {
    final key = AppSettings.geminiKey.trim();
    String? geminiProblem;

    if (key.isNotEmpty) {
      try {
        final r = await _gemini(key: key, text: text);
        _remember(text, r.text);
        return r;
      } on AIException catch (e) {
        geminiProblem = e.message;
      } catch (_) {
        geminiProblem = 'No hubo conexión con Gemini.';
      }
    }

    try {
      final r = await _pollinations(text);
      _remember(text, r.text);
      return r;
    } on AIException catch (e) {
      throw AIException(_join(geminiProblem, e.message));
    } catch (_) {
      throw AIException(_join(
          geminiProblem,
          'No hay conexión a internet. Revisa el WiFi o los datos del celular.'));
    }
  }

  /// Audio (WAV) del micrófono del robot: Gemini lo transcribe y responde.
  static Future<AIReply> askAudio(Uint8List wav) async {
    final key = AppSettings.geminiKey.trim();
    if (key.isEmpty) {
      throw AIException(
          'Para usar el micrófono del robot necesitas una API key gratuita de Gemini '
          '(pestaña Ajustes). Con el micrófono del celular no hace falta.');
    }
    try {
      final r = await _gemini(key: key, wav: wav);
      _remember(r.heard.isEmpty ? '(audio)' : r.heard, r.text);
      return r;
    } on AIException {
      rethrow;
    } catch (_) {
      throw AIException('No hubo conexión con Gemini. Revisa tu internet.');
    }
  }

  // ---------------------------------------------------------------------------
  // Gemini
  // ---------------------------------------------------------------------------

  static Future<AIReply> _gemini({
    required String key,
    String? text,
    Uint8List? wav,
  }) async {
    final models = await _geminiModels(key);
    final isAudio = wav != null;

    final contents = <Map<String, dynamic>>[];
    for (final t in _history) {
      contents.add({
        'role': t.role,
        'parts': [
          {'text': t.text}
        ],
      });
    }
    contents.add({
      'role': 'user',
      'parts': isAudio
          ? [
              {'text': _audioPrompt},
              {
                'inlineData': {'mimeType': 'audio/wav', 'data': base64Encode(wav)}
              },
            ]
          : [
              {'text': text}
            ],
    });

    final body = jsonEncode({
      'systemInstruction': {
        'parts': [
          {'text': _system}
        ]
      },
      'contents': contents,
      'generationConfig': {
        'temperature': 0.7,
        'maxOutputTokens': 1024,
        if (isAudio) 'responseMimeType': 'application/json',
      },
    });

    var lastError = 'Gemini no respondió.';
    for (final model in models) {
      http.Response r;
      try {
        r = await http
            .post(
              Uri.parse('$_gemBase/models/$model:generateContent'),
              headers: {'Content-Type': 'application/json', 'x-goog-api-key': key},
              body: body,
            )
            .timeout(const Duration(seconds: 45));
      } on TimeoutException {
        lastError = 'Gemini tardó demasiado en responder.';
        continue;
      }

      if (r.statusCode == 200) {
        final answer = _parseGemini(r.body, isAudio);
        if (answer != null) {
          AppSettings.workingModel = model;
          return AIReply(
            heard: answer.$1,
            text: answer.$2,
            provider: 'Gemini ($model)',
          );
        }
        lastError = 'Gemini devolvió una respuesta vacía.';
        continue;
      }

      final msg = _errorMessage(r.body);
      lastError = 'Gemini $model: ${r.statusCode} $msg';
      final low = msg.toLowerCase();
      if (r.statusCode == 400 && low.contains('api key')) {
        throw AIException(
            'La API key de Gemini no es válida. Revísala en la pestaña Ajustes.');
      }
      // 404 (modelo retirado), 403/429 (sin cuota en ese modelo), etc. -> probar el siguiente
    }
    throw AIException(lastError);
  }

  /// Devuelve (lo que se oyó, respuesta) o null si no hay texto.
  static (String, String)? _parseGemini(String body, bool isAudio) {
    final dynamic j = jsonDecode(body);
    final dynamic cands = j['candidates'];
    if (cands is! List || cands.isEmpty) return null;
    final dynamic parts = cands[0]['content']?['parts'];
    if (parts is! List) return null;

    final buf = StringBuffer();
    for (final p in parts) {
      if (p is Map && p['thought'] != true && p['text'] is String) {
        buf.write(p['text']);
      }
    }
    final raw = buf.toString().trim();
    if (raw.isEmpty) return null;

    if (!isAudio) return ('', raw);

    var heard = '';
    var answer = raw;
    try {
      final cleaned =
          raw.replaceAll('```json', '').replaceAll('```', '').trim();
      final dynamic m = jsonDecode(cleaned);
      if (m is Map) {
        heard = (m['pregunta'] ?? '').toString().trim();
        final a = (m['respuesta'] ?? '').toString().trim();
        if (a.isNotEmpty) answer = a;
      }
    } catch (_) {
      // si no vino JSON, se usa el texto tal cual
    }
    return (heard, answer);
  }

  static Future<List<String>> _geminiModels(String key) async {
    final out = <String>[];
    void add(String m) {
      if (m.isNotEmpty && !out.contains(m)) out.add(m);
    }

    add(AppSettings.geminiModel.trim());
    add(AppSettings.workingModel.trim());

    _discovered ??= await _discoverModels(key);
    for (final m in _discovered!) {
      add(m);
    }
    for (final m in _fallbackModels) {
      add(m);
    }
    return out.take(8).toList();
  }

  /// Pide a Google la lista real de modelos disponibles para esta key y elige los
  /// "flash" de texto, priorizando estables y "lite" (mejor cuota gratuita).
  static Future<List<String>> _discoverModels(String key) async {
    try {
      final r = await http.get(
        Uri.parse('$_gemBase/models?pageSize=200'),
        headers: {'x-goog-api-key': key},
      ).timeout(const Duration(seconds: 15));
      if (r.statusCode != 200) return [];

      final dynamic j = jsonDecode(r.body);
      final dynamic list = j['models'];
      if (list is! List) return [];

      final bad = RegExp(
          r'image|tts|live|audio|embed|robot|computer|exp|vision|thinking|customtools|dialog|learnlm');
      final names = <String>[];
      for (final m in list) {
        if (m is! Map) continue;
        final name = (m['name'] ?? '').toString().replaceFirst('models/', '');
        final methods = m['supportedGenerationMethods'];
        if (methods is! List || !methods.contains('generateContent')) continue;
        if (!name.startsWith('gemini-') || !name.contains('flash')) continue;
        if (bad.hasMatch(name)) continue;
        names.add(name);
      }

      double version(String n) {
        final mm = RegExp(r'gemini-(\d+(?:\.\d+)?)').firstMatch(n);
        return mm == null ? 0 : double.tryParse(mm.group(1)!) ?? 0;
      }

      names.sort((a, b) {
        final pa = a.contains('preview') ? 1 : 0;
        final pb = b.contains('preview') ? 1 : 0;
        if (pa != pb) return pa - pb;
        final la = a.contains('lite') ? 0 : 1;
        final lb = b.contains('lite') ? 0 : 1;
        if (la != lb) return la - lb;
        return version(b).compareTo(version(a));
      });
      return names;
    } catch (_) {
      return [];
    }
  }

  // ---------------------------------------------------------------------------
  // Pollinations (sin clave)
  // ---------------------------------------------------------------------------

  static Future<AIReply> _pollinations(String text) async {
    final messages = <Map<String, String>>[
      {'role': 'system', 'content': _system},
      for (final t in _history)
        {'role': t.role == 'model' ? 'assistant' : 'user', 'content': t.text},
      {'role': 'user', 'content': text},
    ];

    // 1) Formato compatible con OpenAI
    try {
      final r = await http
          .post(
            Uri.parse('https://text.pollinations.ai/openai'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'model': 'openai', 'messages': messages}),
          )
          .timeout(const Duration(seconds: 40));
      if (r.statusCode == 200) {
        final dynamic j = jsonDecode(utf8.decode(r.bodyBytes));
        final dynamic c = j['choices']?[0]?['message']?['content'];
        if (c is String) {
          final clean = _cleanPollinations(c);
          if (clean != null) {
            return AIReply(heard: '', text: clean, provider: 'Pollinations (sin clave)');
          }
        }
      }
    } on TimeoutException {
      // se intenta el método simple
    } catch (_) {
      // se intenta el método simple
    }

    // 2) GET simple
    try {
      final uri = Uri.https(
        'text.pollinations.ai',
        '/${text.replaceAll('/', ' ')}',
        {'model': 'openai', 'system': _system},
      );
      final r = await http.get(uri).timeout(const Duration(seconds: 40));
      if (r.statusCode == 200) {
        final clean = _cleanPollinations(utf8.decode(r.bodyBytes));
        if (clean != null) {
          return AIReply(heard: '', text: clean, provider: 'Pollinations (sin clave)');
        }
      }
    } on TimeoutException {
      throw AIException('El servicio gratuito sin clave tardó demasiado en responder.');
    }

    throw AIException(
        'El servicio gratuito sin clave no está disponible ahora. '
        'Crea una API key gratis de Gemini en aistudio.google.com/apikey y pégala en Ajustes.');
  }

  /// Quita publicidad/avisos del servicio. Devuelve null si el contenido no es una respuesta real.
  static String? _cleanPollinations(String raw) {
    var t = raw.trim();
    t = t.replaceFirst(
      RegExp(r'[\s\-*_]*(Support Pollinations|Powered by Pollinations|\*\*Sponsor)[\s\S]*$',
          caseSensitive: false),
      '',
    );
    t = t.trim();
    if (t.isEmpty) return null;
    final low = t.toLowerCase();
    if (low.contains('pollinations') &&
        (low.contains('legacy') ||
            low.contains('deprecat') ||
            low.contains('discontinu') ||
            low.contains('migrat'))) {
      return null;
    }
    return t;
  }

  // ---------------------------------------------------------------------------
  // Utilidades
  // ---------------------------------------------------------------------------

  static void _remember(String user, String model) {
    _history.add(_Turn('user', user));
    _history.add(_Turn('model', model));
    while (_history.length > 8) {
      _history.removeAt(0);
    }
  }

  static String _errorMessage(String body) {
    try {
      final dynamic j = jsonDecode(body);
      final dynamic m = j['error']?['message'];
      if (m is String) return m.length > 160 ? '${m.substring(0, 160)}…' : m;
    } catch (_) {}
    return '';
  }

  static String _join(String? a, String b) =>
      (a == null || a.isEmpty) ? b : '$a\n$b';
}
