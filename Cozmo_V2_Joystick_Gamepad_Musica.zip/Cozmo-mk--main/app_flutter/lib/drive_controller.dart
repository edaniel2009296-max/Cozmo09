import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

import 'app_settings.dart';
import 'websocket_manager.dart';

/// arcade = 1 joystick · tank = 2 joysticks (uno por servo) · car = dirección + acelerador
enum DriveMode { arcade, tank, car }

@immutable
class DriveOutput {
  final double left;
  final double right;
  final int servo1;
  final int servo2;
  const DriveOutput(this.left, this.right, this.servo1, this.servo2);
  static const DriveOutput stopped = DriveOutput(0, 0, 90, 90);
}

class _DriveLifecycle with WidgetsBindingObserver {
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      DriveController.stop();
    }
  }
}

/// Cerebro de la conducción. Recibe la posición de los joysticks (pantalla o gamepad),
/// la convierte en velocidad de dos motores y la envía al NodeMCU con el MISMO comando
/// que ya usaba la app: SERVO:<servo1>,<servo2>  (90 = detenido, como en la pestaña Servos).
///
/// Envía como máximo 20 veces por segundo y solo cuando el valor cambia.
class DriveController {
  DriveController._();

  static final ValueNotifier<DriveOutput> output =
      ValueNotifier<DriveOutput>(DriveOutput.stopped);
  static final ValueNotifier<DriveMode> mode = ValueNotifier<DriveMode>(DriveMode.arcade);
  static final ValueNotifier<double> maxSpeed = ValueNotifier<double>(0.6);

  /// Sube cada vez que cambian los ajustes (para refrescar la pantalla).
  static final ValueNotifier<int> revision = ValueNotifier<int>(0);

  // Ajustes en caché (se refrescan con reloadSettings)
  static double _expo = 1.4;
  static double _dzTouch = 0.06;
  static double _dzPad = 0.12;
  static double _minStart = 0;
  static double _range = 90;
  static double _rampSec = 0.3;
  static bool _inv1 = false;
  static bool _inv2 = false;
  static bool _swap = false;

  // Órdenes (-1..1) de cada fuente y valor suavizado actual
  static double _tl = 0;
  static double _tr = 0;
  static double _pl = 0;
  static double _pr = 0;
  static double _cl = 0;
  static double _cr = 0;

  static int? _last1;
  static int? _last2;
  static bool _everMoved = false;
  static bool _estop = false;
  static bool _started = false;
  static Timer? _timer;

  static void init() {
    if (_started) return;
    _started = true;
    final idx = AppSettings.driveMode;
    mode.value = DriveMode.values[(idx >= 0 && idx < DriveMode.values.length) ? idx : 0];
    maxSpeed.value = AppSettings.maxSpeed.clamp(0.1, 1.0).toDouble();
    reloadSettings();
    WebSocketManager.state.addListener(() {
      _last1 = null;
      _last2 = null;
    });
    WidgetsBinding.instance.addObserver(_DriveLifecycle());
    _timer = Timer.periodic(const Duration(milliseconds: 50), _tick);
  }

  static void reloadSettings() {
    _expo = AppSettings.driveExpo;
    _dzTouch = AppSettings.touchDeadzone;
    _dzPad = AppSettings.padDeadzone;
    _minStart = AppSettings.driveMinStart;
    _range = AppSettings.driveRange;
    if (_range < _minStart + 5) _range = _minStart + 5;
    _rampSec = AppSettings.driveRampSec;
    _inv1 = AppSettings.invert1;
    _inv2 = AppSettings.invert2;
    _swap = AppSettings.swapMotors;
    revision.value = revision.value + 1;
  }

  // ------------------------------ entradas ------------------------------

  static void setMode(DriveMode m) {
    stop();
    mode.value = m;
    AppSettings.driveMode = m.index;
  }

  static void cycleMode() {
    setMode(DriveMode.values[(mode.value.index + 1) % DriveMode.values.length]);
  }

  static void setMaxSpeed(double v) {
    final c = v.clamp(0.1, 1.0).toDouble();
    maxSpeed.value = c;
    AppSettings.maxSpeed = c;
  }

  /// Joysticks de la pantalla. Y positiva = adelante, X positiva = derecha.
  /// arcade usa (ax, ay) · tank usa (ay, by) · car usa (ax, by).
  static void touchInput(double ax, double ay, double bx, double by) {
    _store(_compose(mode.value, ax, ay, bx, by, _dzTouch), false);
  }

  /// Gamepad. Valores crudos de Android (en los sticks, arriba = negativo).
  static void padInput(double lx, double ly, double rx, double ry, double lt, double rt) {
    final m = mode.value;
    double ax = 0;
    double ay = 0;
    double bx = 0;
    double by = 0;
    switch (m) {
      case DriveMode.arcade:
        ax = lx;
        ay = -ly;
        break;
      case DriveMode.tank:
        ay = -ly;
        by = -ry;
        break;
      case DriveMode.car:
        ax = lx;
        var th = rt - lt;
        if (th.abs() < 0.03) th = -ry;
        by = th;
        break;
    }
    _store(_compose(m, ax, ay, bx, by, _dzPad), true);
  }

  /// Parada inmediata (sin rampa). Ignora los joysticks hasta que vuelvan al centro.
  static void stop() {
    _tl = 0;
    _tr = 0;
    _pl = 0;
    _pr = 0;
    _cl = 0;
    _cr = 0;
    _estop = true;
    if (WebSocketManager.sendCommand('SERVO:90,90')) {
      _last1 = 90;
      _last2 = 90;
    }
    output.value = DriveOutput.stopped;
  }

  // ------------------------------- cálculo -------------------------------

  static double _shape(double v, double dz) {
    final a = v.abs();
    if (a <= dz) return 0;
    final n = ((a - dz) / (1 - dz)).clamp(0.0, 1.0).toDouble();
    final s = math.pow(n, _expo).toDouble();
    return v < 0 ? -s : s;
  }

  static List<double> _mix(double throttle, double steer) {
    final l = throttle + steer;
    final r = throttle - steer;
    final m = math.max(1.0, math.max(l.abs(), r.abs()));
    return <double>[l / m, r / m];
  }

  static List<double> _compose(
      DriveMode m, double ax, double ay, double bx, double by, double dz) {
    switch (m) {
      case DriveMode.tank:
        return <double>[_shape(ay, dz), _shape(by, dz)];
      case DriveMode.car:
        return _mix(_shape(by, dz), _shape(ax, dz));
      case DriveMode.arcade:
        return _mix(_shape(ay, dz), _shape(ax, dz));
    }
  }

  static void _store(List<double> lr, bool pad) {
    var l = lr[0];
    var r = lr[1];
    if (_estop) {
      if (l.abs() + r.abs() < 0.001) _estop = false;
      l = 0;
      r = 0;
    }
    if (pad) {
      _pl = l;
      _pr = r;
    } else {
      _tl = l;
      _tr = r;
    }
  }

  static double _approach(double cur, double target) {
    final accel = _rampSec <= 0.05 ? 1.0 : (0.05 / _rampSec);
    final accelerating = target.abs() > cur.abs() && target * cur >= 0;
    final step = accelerating ? accel : math.min(1.0, accel * 3);
    final d = target - cur;
    if (d.abs() <= step) return target;
    return cur + (d > 0 ? step : -step);
  }

  static int _angle(double v, bool invert) {
    if (v.abs() < 0.01) return 90;
    final s = invert ? -v : v;
    final off = _minStart + s.abs() * (_range - _minStart);
    final a = s < 0 ? 90 - off : 90 + off;
    return a.round().clamp(0, 180).toInt();
  }

  static void _tick(Timer t) {
    final padActive = (_pl.abs() + _pr.abs()) > 0.001;
    final tl = padActive ? _pl : _tl;
    final tr = padActive ? _pr : _tr;
    final k = maxSpeed.value;
    _cl = _approach(_cl, tl * k);
    _cr = _approach(_cr, tr * k);

    final s1v = _swap ? _cr : _cl;
    final s2v = _swap ? _cl : _cr;
    final a1 = _angle(s1v, _inv1);
    final a2 = _angle(s2v, _inv2);

    if (!_everMoved && (a1 != 90 || a2 != 90)) _everMoved = true;
    if (_everMoved && (a1 != _last1 || a2 != _last2)) {
      if (WebSocketManager.sendCommand('SERVO:$a1,$a2')) {
        _last1 = a1;
        _last2 = a2;
      }
    }

    final o = output.value;
    if (a1 != o.servo1 ||
        a2 != o.servo2 ||
        (_cl - o.left).abs() > 0.02 ||
        (_cr - o.right).abs() > 0.02) {
      output.value = DriveOutput(_cl, _cr, a1, a2);
    }
  }
}
