import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'app_settings.dart';
import 'bluetooth_manager.dart';

/// phone = audio normal del celular: sale por el parlante Bluetooth (A2DP) si hay uno
///         conectado (placa de parlante viejo) o por el altavoz del celular.
/// hc05  = por el HC-05 #2 -> Arduino -> amplificador -> parlante del robot.
enum MusicOutput { phone, hc05 }

enum RepeatMode { off, all, one }

class Track {
  final String path;
  final String title;
  const Track(this.path, this.title);
}

/// Reproductor de música (lista, aleatorio, repetir, volumen, buscar).
/// El audio lo maneja el código nativo (MusicEngine en MainActivity.kt).
class MusicManager {
  MusicManager._();

  static const MethodChannel _m = MethodChannel('cozmo/music');

  static final ValueNotifier<List<Track>> playlist = ValueNotifier<List<Track>>(<Track>[]);
  static final ValueNotifier<int> currentIndex = ValueNotifier<int>(-1);
  static final ValueNotifier<bool> playing = ValueNotifier<bool>(false);
  static final ValueNotifier<int> positionMs = ValueNotifier<int>(0);
  static final ValueNotifier<int> durationMs = ValueNotifier<int>(0);
  static final ValueNotifier<String> error = ValueNotifier<String>('');
  static final ValueNotifier<bool> shuffle = ValueNotifier<bool>(false);
  static final ValueNotifier<RepeatMode> repeat = ValueNotifier<RepeatMode>(RepeatMode.all);
  static final ValueNotifier<double> volume = ValueNotifier<double>(0.8);
  static final ValueNotifier<MusicOutput> output = ValueNotifier<MusicOutput>(MusicOutput.phone);

  static final math.Random _rng = math.Random();
  static Timer? _poll;
  static bool _polling = false;
  static bool _loaded = false;
  static bool _heldForVoice = false;
  static int _errStreak = 0;
  static bool _started = false;

  static void init() {
    if (_started) return;
    _started = true;
    volume.value = AppSettings.musicVolume.clamp(0.0, 1.0).toDouble();
    output.value = AppSettings.musicOutput == 'hc05' ? MusicOutput.hc05 : MusicOutput.phone;
    final tracks = <Track>[];
    for (final s in AppSettings.musicPlaylist) {
      try {
        final j = jsonDecode(s);
        if (j is Map) {
          final p = (j['path'] ?? '').toString();
          if (p.isNotEmpty && File(p).existsSync()) {
            tracks.add(Track(p, (j['title'] ?? p).toString()));
          }
        }
      } catch (_) {
        // entrada dañada: se ignora
      }
    }
    playlist.value = tracks;
  }

  static void _save() {
    AppSettings.musicPlaylist = playlist.value
        .map((t) => jsonEncode(<String, String>{'path': t.path, 'title': t.title}))
        .toList();
  }

  // ------------------------------- lista -------------------------------

  static void addTracks(List<Track> tracks) {
    if (tracks.isEmpty) return;
    playlist.value = <Track>[...playlist.value, ...tracks];
    _save();
  }

  static Future<void> removeAt(int i) async {
    final list = List<Track>.from(playlist.value);
    if (i < 0 || i >= list.length) return;
    final cur = currentIndex.value;
    if (i == cur) {
      await stop();
      currentIndex.value = -1;
    } else if (i < cur) {
      currentIndex.value = cur - 1;
    }
    list.removeAt(i);
    playlist.value = list;
    _save();
  }

  static Future<void> clear() async {
    await stop();
    currentIndex.value = -1;
    playlist.value = <Track>[];
    _save();
  }

  // --------------------------- reproducción ---------------------------

  static String get _outName => output.value == MusicOutput.hc05 ? 'hc05' : 'phone';

  static Future<void> playIndex(int i, {int startMs = 0}) async {
    final list = playlist.value;
    if (i < 0 || i >= list.length) return;
    currentIndex.value = i;
    error.value = '';

    if (output.value == MusicOutput.hc05 &&
        BluetoothManager.txState.value != BtState.connected) {
      playing.value = false;
      _loaded = false;
      error.value =
          'El HC-05 #2 no está conectado. Conéctalo en la pestaña Conexión o cambia la salida a «Parlante BT».';
      return;
    }

    try {
      final res = await _m.invokeMapMethod<String, dynamic>('load', <String, dynamic>{
        'path': list[i].path,
        'output': _outName,
        'rate': AppSettings.sampleRate,
        'volume': volume.value,
        'start': startMs,
      });
      durationMs.value = (res?['duration'] as num?)?.toInt() ?? 0;
      positionMs.value = startMs;
      await _m.invokeMethod<bool>('play');
      _loaded = true;
      _errStreak = 0;
      playing.value = true;
      _startPoll();
    } on PlatformException catch (e) {
      _loaded = false;
      playing.value = false;
      error.value = e.message ?? 'No se pudo reproducir la canción';
      _errStreak++;
      // Si una canción falla, intenta la siguiente (máximo una vuelta a la lista)
      if (_errStreak < list.length && list.length > 1) {
        await next(auto: true);
      }
    }
  }

  static Future<void> togglePlay() async {
    if (playlist.value.isEmpty) return;
    if (!_loaded) {
      final c = currentIndex.value;
      await playIndex(c < 0 ? 0 : c);
      return;
    }
    try {
      if (playing.value) {
        await _m.invokeMethod<bool>('pause');
        playing.value = false;
      } else {
        await _m.invokeMethod<bool>('play');
        playing.value = true;
        _startPoll();
      }
    } on PlatformException catch (e) {
      error.value = e.message ?? 'Error de reproducción';
    }
  }

  static Future<void> next({bool auto = false}) async {
    final n = playlist.value.length;
    if (n == 0) return;
    final cur = currentIndex.value;
    int target = cur + 1;
    if (shuffle.value && n > 1) {
      do {
        target = _rng.nextInt(n);
      } while (target == cur);
    } else if (target >= n) {
      if (repeat.value == RepeatMode.all || !auto) {
        target = 0;
      } else {
        await stop();
        return;
      }
    }
    await playIndex(target);
  }

  static Future<void> prev() async {
    final n = playlist.value.length;
    if (n == 0) return;
    if (_loaded && positionMs.value > 3000) {
      await seekTo(0);
      return;
    }
    int target = currentIndex.value - 1;
    if (target < 0) target = n - 1;
    await playIndex(target);
  }

  static Future<void> stop() async {
    _stopPoll();
    try {
      await _m.invokeMethod<bool>('stop');
    } on PlatformException {
      // ignorar
    }
    _loaded = false;
    playing.value = false;
    positionMs.value = 0;
  }

  static Future<void> seekTo(int ms) async {
    if (!_loaded) return;
    try {
      await _m.invokeMethod<bool>('seek', <String, dynamic>{'ms': ms});
      positionMs.value = ms;
    } on PlatformException {
      // ignorar
    }
  }

  static Future<void> setVolume(double v) async {
    final c = v.clamp(0.0, 1.0).toDouble();
    volume.value = c;
    AppSettings.musicVolume = c;
    try {
      await _m.invokeMethod<bool>('volume', <String, dynamic>{'v': c});
    } on PlatformException {
      // ignorar
    }
  }

  static Future<void> changeVolume(double delta) => setVolume(volume.value + delta);

  static void toggleShuffle() => shuffle.value = !shuffle.value;

  static void cycleRepeat() {
    repeat.value = RepeatMode.values[(repeat.value.index + 1) % RepeatMode.values.length];
  }

  static Future<void> setOutput(MusicOutput o) async {
    if (output.value == o) return;
    final was = playing.value;
    final pos = positionMs.value;
    final idx = currentIndex.value;
    final wasLoaded = _loaded;
    output.value = o;
    AppSettings.musicOutput = o == MusicOutput.hc05 ? 'hc05' : 'phone';
    error.value = '';
    if (wasLoaded && idx >= 0) {
      await stop();
      currentIndex.value = idx;
      if (was) {
        await playIndex(idx, startMs: pos);
      } else {
        positionMs.value = pos;
      }
    }
  }

  // ----------------- pausa automática cuando el robot habla -----------------

  static Future<void> pauseForVoice() async {
    if (!playing.value) return;
    try {
      await _m.invokeMethod<bool>('pause');
      playing.value = false;
      _heldForVoice = true;
    } on PlatformException {
      // ignorar
    }
  }

  static Future<void> resumeAfterVoice() async {
    if (!_heldForVoice) return;
    _heldForVoice = false;
    if (!_loaded) return;
    try {
      await _m.invokeMethod<bool>('play');
      playing.value = true;
      _startPoll();
    } on PlatformException {
      // ignorar
    }
  }

  // ------------------------------- estado -------------------------------

  static void _startPoll() {
    _poll ??= Timer.periodic(const Duration(milliseconds: 400), (_) => _pollOnce());
  }

  static void _stopPoll() {
    _poll?.cancel();
    _poll = null;
  }

  static Future<void> _pollOnce() async {
    if (_polling) return;
    _polling = true;
    try {
      final s = await _m.invokeMapMethod<String, dynamic>('status');
      if (s == null) return;
      final st = (s['state'] ?? 'idle').toString();
      positionMs.value = (s['pos'] as num?)?.toInt() ?? 0;
      final d = (s['dur'] as num?)?.toInt() ?? 0;
      if (d > 0) durationMs.value = d;
      if (st == 'ended') {
        playing.value = false;
        _stopPoll();
        await _onEnded();
      } else if (st == 'error') {
        playing.value = false;
        _loaded = false;
        _stopPoll();
        final err = (s['error'] ?? '').toString();
        error.value = err.isEmpty ? 'Error de reproducción' : err;
      } else {
        playing.value = st == 'playing' || (_heldForVoice && st == 'paused');
      }
    } catch (_) {
      // ignorar
    } finally {
      _polling = false;
    }
  }

  static Future<void> _onEnded() async {
    if (repeat.value == RepeatMode.one) {
      await playIndex(currentIndex.value);
    } else {
      await next(auto: true);
    }
  }
}
