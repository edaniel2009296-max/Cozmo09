import 'package:flutter/services.dart';

class AudioRoute {
  final bool a2dp;
  final String name;
  const AudioRoute(this.a2dp, this.name);
}

/// Utilidades del sistema Android (ruta de audio, ajustes Bluetooth, pantalla encendida).
class SystemBridge {
  static const MethodChannel _c = MethodChannel('cozmo/sys');

  /// ¿Hay un parlante Bluetooth (A2DP) conectado al celular?
  static Future<AudioRoute> audioRoute() async {
    try {
      final m = await _c.invokeMapMethod<String, dynamic>('audioRoute');
      return AudioRoute(m?['a2dp'] == true, (m?['name'] ?? '').toString());
    } catch (_) {
      return const AudioRoute(false, '');
    }
  }

  static Future<void> openBluetoothSettings() async {
    try {
      await _c.invokeMethod<bool>('openBtSettings');
    } catch (_) {
      // ignorar
    }
  }

  static Future<void> keepScreenOn(bool on) async {
    try {
      await _c.invokeMethod<bool>('keepScreenOn', {'on': on});
    } catch (_) {
      // ignorar
    }
  }
}
