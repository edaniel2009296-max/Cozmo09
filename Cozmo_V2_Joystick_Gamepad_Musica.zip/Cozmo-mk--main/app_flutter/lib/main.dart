import 'package:flutter/material.dart';

import 'app_settings.dart';
import 'bluetooth_manager.dart';
import 'drive_controller.dart';
import 'gamepad_manager.dart';
import 'music_manager.dart';
import 'system_bridge.dart';
import 'screens/connection_screen.dart';
import 'screens/drive_screen.dart';
import 'screens/music_screen.dart';
import 'screens/oled_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/voice_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppSettings.init();
  BluetoothManager.init();
  GamepadManager.init();
  DriveController.init();
  MusicManager.init();
  SystemBridge.keepScreenOn(AppSettings.keepAwake);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cozmo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blue,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blue,
        brightness: Brightness.dark,
      ),
      themeMode: ThemeMode.system,
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    ConnectionScreen(),
    VoiceScreen(),
    OledScreen(),
    DriveScreen(),
    MusicScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cozmo')),
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
        onDestinationSelected: (i) => setState(() => _currentIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.bluetooth_connected), label: 'Conexión'),
          NavigationDestination(icon: Icon(Icons.mic), label: 'Voz IA'),
          NavigationDestination(icon: Icon(Icons.face), label: 'OLED'),
          NavigationDestination(icon: Icon(Icons.sports_esports), label: 'Conducir'),
          NavigationDestination(icon: Icon(Icons.music_note), label: 'Música'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Ajustes'),
        ],
      ),
    );
  }
}
