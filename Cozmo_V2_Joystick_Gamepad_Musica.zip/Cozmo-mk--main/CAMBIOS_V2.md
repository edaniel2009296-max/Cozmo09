# Cozmo – Versión 2: conducción con joystick, gamepad Bluetooth y música

Todo lo que ya funcionaba **sigue igual**: conexión (NodeMCU + 2 HC-05), Voz IA, OLED, Ajustes,
comandos `SERVO:a,b` y `FACE:..|TEXT:..` y el formato de audio del HC-05. No hay que tocar el
firmware del NodeMCU ni del Arduino.

## 1. Pestaña «Conducir» (reemplaza a «Servos»)

Arriba eliges el modo:

| Modo | Controles en pantalla | Para qué |
|---|---|---|
| **Arcade** | 1 joystick (adelante/atrás + giro) | El más natural, con un pulgar |
| **Tanque** | 2 joysticks verticales (uno por servo) | Control total de cada lado |
| **Auto** | Dirección (izq.) + Acelerador (der.) | Como un auto RC, con dos pulgares |
| **Servos** | La pantalla de siempre (D-pad y sliders) | Sin cambios, por si la necesitas |

* **Pantalla completa** (botón ⛶): se pone en horizontal, con dos pulgares, STOP siempre a la vista.
* **STOP** grande: frena al instante. Además el robot se frena solo si sales de la app o apagas la pantalla.
* **Velocidad máxima** con slider, **aceleración suave**, **curva de sensibilidad** y **zona muerta**.
* Envía como máximo 20 comandos por segundo y solo cuando algo cambia (no satura el NodeMCU).
* Botón ⚙ (Ajustes de conducción):
  * *Invertir servo 1 / 2* e *Intercambiar servo 1 ↔ 2*: si el robot gira al revés o no avanza recto.
  * *Arranque mínimo*: los servos de rotación continua no se mueven cerca de 90°; sube este valor
    hasta que el robot arranque apenas muevas el joystick.
  * *Recorrido máximo*, *modo zurdo*, *mantener pantalla encendida*.

Convención de servos (igual a tu D-pad de antes): servo 1 = lado izquierdo, servo 2 = lado derecho,
90° = detenido, más de 90° = adelante. Si en tu robot es al revés, usa los interruptores de inversión.

## 2. Gamepad Bluetooth

1. Pon el gamepad en modo emparejamiento y vincúlalo en **Ajustes Bluetooth del celular**
   (botón «Emparejar gamepad» en ⚙). No se conecta desde la app: Android lo trata como teclado/mando.
2. Al conectarse aparece su nombre en la pestaña Conducir.

| Control | Acción |
|---|---|
| Stick izq. (modo Arcade) | Conducir |
| Sticks izq. y der. (Tanque) | Cada stick = un lado |
| R2 / L2 + stick izq. (Auto) | Acelerar / reversa + dirección |
| A, B, X, Y | Caras del OLED `^_^`  `T_T`  `O_o`  `>_<` |
| L1 / R1 | Bajar / subir velocidad máxima |
| **Start** | **STOP de emergencia** |
| Select | Cambiar de modo |
| L3 (clic stick izq.) | Play / pausa música |
| Cruceta ← → / ↑ ↓ | Canción anterior-siguiente / volumen |

Funciona en cualquier pestaña (se puede desactivar en ⚙). El control táctil y el gamepad se pueden
usar a la vez: el gamepad tiene prioridad mientras lo muevas.

## 3. Pestaña «Música» (separada del resto)

Eliges canciones de tu celular (mp3, m4a, wav, ogg, flac…): lista, aleatorio, repetir, volumen, barra
de avance, siguiente/anterior. Hay **dos salidas**:

### A) «Parlante BT» – placa Bluetooth de un parlante viejo (recomendado para música)
* El audio sale por el sistema Android hacia la placa (perfil A2DP). **No usa HC-05.**
* Calidad de música normal. Pasos: enciende la placa → empárejala una vez en Ajustes Bluetooth →
  en la app se ve «Sonando por el parlante Bluetooth: …».
* Conexión: la placa va con su propio parlante en sus terminales de salida y se alimenta con 5 V
  (o su batería/USB). Une las masas (GND) con el resto del robot si comparten fuente. Si la placa
  trae su propio amplificador, no necesitas otro.
* Si no hay ningún parlante BT conectado, suena en el celular (la app te avisa).
* Bonus: la voz de Cozmo también saldrá por esa placa si dejas activo «Hablar en el celular».

### B) «HC-05 #2» – amplificador del robot
* La app decodifica la canción y la manda por el **HC-05 #2** en el mismo formato que ya usa la voz
  (PCM 8 bits mono a la frecuencia de Ajustes), hacia el Arduino y el amplificador.
  El firmware que reproduce la voz reproduce también la música.
* **Limitación física:** el HC-05 solo hace Bluetooth serie (SPP), no audio estéreo. Con 8 bits y
  8000–16000 Hz la calidad es tipo radio AM. Para buena música usa la opción A.
* La música debe ir a la misma frecuencia que configuraste para la voz. Para subir de 8000 a
  11025/16000 Hz el HC-05 y el Arduino deben estar a 115200 baudios o más.
* Si el robot habla, la música se pausa sola y se reanuda al terminar.

## 4. Archivos nuevos / modificados

Nuevos: `lib/drive_controller.dart`, `lib/gamepad_manager.dart`, `lib/music_manager.dart`,
`lib/system_bridge.dart`, `lib/widgets/joystick.dart`, `lib/screens/drive_screen.dart`,
`lib/screens/music_screen.dart`.

Modificados (solo se agregó, no se quitó nada): `main.dart` (pestañas), `app_settings.dart`
(ajustes nuevos), `screens/voice_screen.dart` (pausar música mientras habla),
`android_overlay/MainActivity.kt` (gamepad + motor de música), `AndroidManifest.xml`
(permiso WAKE_LOCK), `pubspec.yaml` (`file_picker`). `build.yml` y `servo_screen.dart` no cambian.

## 5. Notas
* La música y el gamepad necesitan la app abierta (no hay servicio en segundo plano); por eso se
  mantiene la pantalla encendida por defecto.
* Las canciones se copian a la caché de la app al elegirlas; si Android limpia la caché, la lista
  se depura sola y solo hay que volver a agregarlas.
